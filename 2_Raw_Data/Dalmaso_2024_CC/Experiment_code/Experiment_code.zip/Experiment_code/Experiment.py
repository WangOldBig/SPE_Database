﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2022.2.5),
    on Fri Jan 27 17:12:55 2023
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

# --- Import packages ---
from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock, colors, layout
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle, choice as randchoice
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)
# Store info about the experiment session
psychopyVersion = '2022.2.5'
expName = 'self_w_b'  # from the Builder filename that created this script
expInfo = {
    'participant': '',
    'age (years)': '',
    'sex': ['female', 'male'],
    'dominant hand': ['right', 'left', 'both'],
}
# --- Show participant info dialog --
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='/Users/mariodalmaso/Desktop/Codice_Exp_OK/MARIO_jap_modified_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run after the window creation

# --- Setup the Window ---
win = visual.Window(
    size=[1440, 900], fullscr=True, screen=0, 
    winType='pyglet', allowStencil=False,
    monitor='testMonitor', color=[1,1,1], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
win.mouseVisible = False
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess
# --- Setup input devices ---
ioConfig = {}
ioSession = ioServer = eyetracker = None

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard(backend='event')

# --- Initialize components for Routine "select_condition" ---
# Run 'Begin Experiment' code from sel_cond
if expInfo["participant"] in ["1","9","17","25","33"]:
    Cond_code = 1
    IAT_code = 1
elif expInfo["participant"] in ["5","13","21","29","37"]:
    Cond_code = 1
    IAT_code = 2
elif expInfo["participant"] in ["2","10","18","26","34"]:
    Cond_code = 2
    IAT_code = 1
elif expInfo["participant"] in ["6","14","22","30","38"]:
    Cond_code = 2
    IAT_code = 2
elif expInfo["participant"] in ["3","11","19","27","35"]:
    Cond_code = 3
    IAT_code = 1
elif expInfo["participant"] in ["7","15","23","31","39"]:
    Cond_code = 3
    IAT_code = 2
elif expInfo["participant"] in ["4","12","20","28","36"]:
    Cond_code = 4
    IAT_code = 1
elif expInfo["participant"] in ["8","16","24","32","40"]:
    Cond_code = 4
    IAT_code = 2

# --- Initialize components for Routine "instructions" ---
# Run 'Begin Experiment' code from code_3
blocks_file = "blocks_order"+str(IAT_code)+expInfo['sex']+".xlsx"
instructs_text = visual.TextStim(win=win, name='instructs_text',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=(0, 0), height=0.025, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-1.0);
instruct_done = keyboard.Keyboard()
instr_done_button = visual.Rect(
    win=win, name='instr_done_button',units='height', 
    width=(0.5, 0.1)[0], height=(0.5, 0.1)[1],
    ori=0.0, pos=(0, -0.4), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='darkgreen', fillColor='lightgreen',
    opacity=1.0, depth=-3.0, interpolate=True)
instr_done_label = visual.TextStim(win=win, name='instr_done_label',
    text='バーを押して続行…',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=(0, -0.4), height=0.03, wrapWidth=None, ori=0.0, 
    color='darkgreen', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-4.0);
# Run 'Begin Experiment' code from hide_mouse_2
win.mouseVisible = True

# --- Initialize components for Routine "ready" ---
main_ready_msg = visual.TextStim(win=win, name='main_ready_msg',
    text='以下の 2 つのカテゴリに注意してください\n \n答えのキーに人差し指を置きます\n \nスペースバーを押して開始します',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=(0, 0), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=0.0);
button_L = visual.Rect(
    win=win, name='button_L',units='height', 
    width=(0.4, 0.2)[0], height=(0.4, 0.2)[1],
    ori=0.0, pos=(-0.4, -0.3), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='darkgreen', fillColor='lightgreen',
    opacity=1.0, depth=-1.0, interpolate=True)
ready_label_L = visual.TextStim(win=win, name='ready_label_L',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=[-0.4, -0.3], height=0.05, wrapWidth=None, ori=0.0, 
    color='darkgreen', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-2.0);
button_R = visual.Rect(
    win=win, name='button_R',units='height', 
    width=(0.4, 0.2)[0], height=(0.4, 0.2)[1],
    ori=0.0, pos=(0.4, -0.3), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='darkgreen', fillColor='lightgreen',
    opacity=1.0, depth=-3.0, interpolate=True)
ready_label_R = visual.TextStim(win=win, name='ready_label_R',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=[0.4, -0.3], height=0.05, wrapWidth=None, ori=0.0, 
    color='darkgreen', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-4.0);
ready_done = keyboard.Keyboard()

# --- Initialize components for Routine "trial_iat" ---
fixation = visual.TextStim(win=win, name='fixation',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=(0, 0), height=0.1, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=0.0);
text_stim = visual.TextStim(win=win, name='text_stim',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-1.0);
image_stim = visual.ImageStim(
    win=win,
    name='image_stim', units='height', 
    image='sin', mask=None, anchor='center',
    ori=0.0, pos=[0, 0], size=[0.5, 0.5],
    color=[1,1,1], colorSpace='rgb', opacity=1.0,
    flipHoriz=False, flipVert=False,
    texRes=128.0, interpolate=True, depth=-2.0)
key_resp_iat = keyboard.Keyboard()
button_left = visual.Rect(
    win=win, name='button_left',units='height', 
    width=(0.4, 0.2)[0], height=(0.4, 0.2)[1],
    ori=0.0, pos=(-0.4, -0.3), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='darkgreen', fillColor='lightgreen',
    opacity=1.0, depth=-5.0, interpolate=True)
trial_label_left = visual.TextStim(win=win, name='trial_label_left',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=[-0.4, -0.3], height=0.05, wrapWidth=None, ori=0.0, 
    color='darkgreen', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-6.0);
button_right = visual.Rect(
    win=win, name='button_right',units='height', 
    width=(0.4, 0.2)[0], height=(0.4, 0.2)[1],
    ori=0.0, pos=(0.4, -0.3), anchor='center',
    lineWidth=1.0,     colorSpace='rgb',  lineColor='darkgreen', fillColor='lightgreen',
    opacity=1.0, depth=-7.0, interpolate=True)
trial_label_right = visual.TextStim(win=win, name='trial_label_right',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=[0.4, -0.3], height=0.05, wrapWidth=None, ori=0.0, 
    color='darkgreen', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-8.0);

# --- Initialize components for Routine "feedback_iat" ---
feedback_msg = visual.TextStim(win=win, name='feedback_msg',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    units='height', pos=[0, 0], height=0.1, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "start_self" ---
text_18 = visual.TextStim(win=win, name='text_18',
    text='最初の実験は終わりました。\n\n新しいタスクを開始するには、スペース バーを押します。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.02, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_14 = keyboard.Keyboard()

# --- Initialize components for Routine "intro" ---
text_2 = visual.TextStim(win=win, name='text_2',
    text='次の画面では、実験に関する重要な情報が表示されます。\n\nそれらを読んで覚える必要があります。ご覧のとおり、これは小さな情報ですが、注意深く覚えておいてください。\n\nまた、次の画面は 40 秒間呈示なままになり、その後自動的に消えまするので、キーを押す必要はなく、覚えることに集中してください。\n\n次の情報画面に移動するには、スペース バーを押します。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.02, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp = keyboard.Keyboard()

# --- Initialize components for Routine "associazione_w" ---
text_3 = visual.TextStim(win=win, name='text_3',
    text='このタスクでは:\n\nあなたは白人です\n\n他の人はアジア人です',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "istruzioni_w_a1" ---
text_6 = visual.TextStim(win=win, name='text_6',
    text='次の課題では、画面の中央に十字が表示されます。\n\n次に、「白人」か「アジア人」の顔が「あなた」または「別の人」という単語と一緒に表示されます。\n\nもし単語と顔の関連性が正しければ（例えば、「白人」と「あなた」や「アジア人」と「別の人」）、”A”キーを押してください。\n\nもし単語と顔の関連性が間違っていれば（例えば、「白人」と「別の人」や「アジア人」や「あなた」）、”L”キーを押してください。\n\nできるるだけ速く、正確に解凍するようにしてください。また画面中央の十字を見続けるようにしてください。それでは、人差し指を”A”と”L”キーにのせてください。\n\nスペースキーを押して練習を開始する。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_3 = keyboard.Keyboard()

# --- Initialize components for Routine "istruzioni_w_l1" ---
text_12 = visual.TextStim(win=win, name='text_12',
    text='次の課題では、画面の中央に十字が表示されます。\n\n次に、「白人」か「アジア人」の顔が「あなた」または「別の人」という単語と一緒に表示されます。\n\nもし単語と顔の関連性が正しければ（例えば、「白人」と「あなた」や「アジア人」と「別の人」）、”L”キーを押してください。\n\nもし単語と顔の関連性が間違っていれば（例えば、「白人」と「別の人」や「アジア人」や「あなた」）、”A”キーを押してください。\n\nできるるだけ速く、正確に解凍するようにしてください。また画面中央の十字を見続けるようにしてください。それでは、人差し指を”A”と”L”キーにのせてください。\n\nスペースキーを押して練習を開始する。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_8 = keyboard.Keyboard()

# --- Initialize components for Routine "istruzioni_w_a2" ---
text_14 = visual.TextStim(win=win, name='text_14',
    text='課題は前回のものと全く同じです。あなたと顔の関係性だけが変化します。\n\n以下は、前回の課題と同じ教示です。\n\n次の課題では、画面の中央に十字が表示されます。\n\n次に、「白人」か「アジア人」の顔が「あなた」または「別の人」という単語と一緒に表示されます。\n\nもし単語と顔の関連性が正しければ（例えば、「白人」と「あなた」や「アジア人」と「別の人」）、”A”キーを押してください。\n\nもし単語と顔の関連性が間違っていれば（例えば、「白人」と「別の人」や「アジア人」や「あなた」）、”L”キーを押してください。\n\nできるるだけ速く、正確に解凍するようにしてください。また画面中央の十字を見続けるようにしてください。それでは、人差し指を”A”と”L”キーにのせてください。\n\nスペースキーを押して練習を開始する。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_10 = keyboard.Keyboard()

# --- Initialize components for Routine "istruzioni_w_l2" ---
text_15 = visual.TextStim(win=win, name='text_15',
    text='課題は前回のものと全く同じです。あなたと顔の関係性だけが変化します。\n\n以下は、前回の課題と同じ教示です。\n\n次の課題では、画面の中央に十字が表示されます。\n\n次に、「白人」か「アジア人」の顔が「あなた」または「別の人」という単語と一緒に表示されます。\n\nもし単語と顔の関連性が正しければ（例えば、「白人」と「あなた」や「アジア人」と「別の人」）、”L”キーを押してください。\n\nもし単語と顔の関連性が間違っていれば（例えば、「白人」と「別の人」や「アジア人」や「あなた」）、”A”キーを押してください。\n\nできるるだけ速く、正確に解凍するようにしてください。また画面中央の十字を見続けるようにしてください。それでは、人差し指を”A”と”L”キーにのせてください。\n\nスペースキーを押して練習を開始する。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_11 = keyboard.Keyboard()

# --- Initialize components for Routine "trial" ---
fix = visual.TextStim(win=win, name='fix',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image = visual.ImageStim(
    win=win,
    name='image', units='pix', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,180], size=[300,300],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
fix2 = visual.TextStim(win=win, name='fix2',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-2.0);
label = visual.TextStim(win=win, name='label',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, -0.05), height=0.04, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
risposta = keyboard.Keyboard()

# --- Initialize components for Routine "feedback" ---
# Run 'Begin Experiment' code from code
msg=' '
text_7 = visual.TextStim(win=win, name='text_7',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "inizio_blocco" ---
text_5 = visual.TextStim(win=win, name='text_5',
    text='練習は終わりました。\n\nこれから本番を開始します。本番では練習と同様の課題を行います。\n\nスペースバーを押して実験を開始します',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "trial" ---
fix = visual.TextStim(win=win, name='fix',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image = visual.ImageStim(
    win=win,
    name='image', units='pix', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,180], size=[300,300],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
fix2 = visual.TextStim(win=win, name='fix2',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-2.0);
label = visual.TextStim(win=win, name='label',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, -0.05), height=0.04, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
risposta = keyboard.Keyboard()

# --- Initialize components for Routine "feedback" ---
# Run 'Begin Experiment' code from code
msg=' '
text_7 = visual.TextStim(win=win, name='text_7',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "chiama_pausa" ---
text_10 = visual.TextStim(win=win, name='text_10',
    text='これで少し休憩できますが、PC から離れないでください。\n\nスペースバーを押して再開します。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_6 = keyboard.Keyboard()

# --- Initialize components for Routine "associazione_b" ---
text_4 = visual.TextStim(win=win, name='text_4',
    text='このタスクでは:\n\nあなたはアジア人です\n\n別の人は白人です',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# --- Initialize components for Routine "istruzioni_a_a1" ---
text_16 = visual.TextStim(win=win, name='text_16',
    text='次の課題では、画面の中央に十字が表示されます。\n\n次に、「白人」か「アジア人」の顔が「あなた」または「別の人」という単語と一緒に表示されます。\n\nもし単語と顔の関連性が正しければ（例えば、「アジア人」と「あなた」や「白人」と「別の人」）、”A”キーを押してください。\n\nもし単語と顔の関連性が間違っていれば（例えば、「アジア人」と「別の人」や「白人」や「あなた」）、”L”キーを押してください。\n\nできるるだけ速く、正確に解凍するようにしてください。また画面中央の十字を見続けるようにしてください。それでは、人差し指を”A”と”L”キーにのせてください。\n\nスペースキーを押して練習を開始する。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_12 = keyboard.Keyboard()

# --- Initialize components for Routine "istruzioni_a_l1" ---
text_17 = visual.TextStim(win=win, name='text_17',
    text='次の課題では、画面の中央に十字が表示されます。\n\n次に、「白人」か「アジア人」の顔が「あなた」または「別の人」という単語と一緒に表示されます。\n\nもし単語と顔の関連性が正しければ（例えば、「アジア人」と「あなた」や「白人」と「別の人」）、”L”キーを押してください。\n\nもし単語と顔の関連性が間違っていれば（例えば、「アジア人」と「別の人」や「白人」や「あなた」）、”A”キーを押してください。\n\nできるるだけ速く、正確に解凍するようにしてください。また画面中央の十字を見続けるようにしてください。それでは、人差し指を”A”と”L”キーにのせてください。\n\nスペースキーを押して練習を開始する。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_13 = keyboard.Keyboard()

# --- Initialize components for Routine "istruzioni_a_a2" ---
text_9 = visual.TextStim(win=win, name='text_9',
    text='課題は前回のものと全く同じです。あなたと顔の関係性だけが変化します。\n\n以下は、前回の課題と同じ教示です。\n\n次の課題では、画面の中央に十字が表示されます。\n\n次に、「白人」か「アジア人」の顔が「あなた」または「別の人」という単語と一緒に表示されます。\n\nもし単語と顔の関連性が正しければ（例えば、「アジア人」と「あなた」や「白人」と「別の人」）、”A”キーを押してください。\n\nもし単語と顔の関連性が間違っていれば（例えば、「アジア人」と「別の人」や「白人」や「あなた」）、”L”キーを押してください。\n\nできるるだけ速く、正確に解凍するようにしてください。また画面中央の十字を見続けるようにしてください。それでは、人差し指を”A”と”L”キーにのせてください。\n\nスペースキーを押して練習を開始する。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_5 = keyboard.Keyboard()

# --- Initialize components for Routine "istruzioni_a_l2" ---
text_13 = visual.TextStim(win=win, name='text_13',
    text='課題は前回のものと全く同じです。あなたと顔の関係性だけが変化します。\n\n以下は、前回の課題と同じ教示です。\n\n次の課題では、画面の中央に十字が表示されます。\n\n次に、「白人」か「アジア人」の顔が「あなた」または「別の人」という単語と一緒に表示されます。\n\nもし単語と顔の関連性が正しければ（例えば、「アジア人」と「あなた」や「白人」と「別の人」）、”L”キーを押してください。\n\nもし単語と顔の関連性が間違っていれば（例えば、「アジア人」と「別の人」や「白人」や「あなた」）、”A”キーを押してください。\n\nできるるだけ速く、正確に解凍するようにしてください。また画面中央の十字を見続けるようにしてください。それでは、人差し指を”A”と”L”キーにのせてください。\n\nスペースキーを押して練習を開始する。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_9 = keyboard.Keyboard()

# --- Initialize components for Routine "trial" ---
fix = visual.TextStim(win=win, name='fix',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image = visual.ImageStim(
    win=win,
    name='image', units='pix', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,180], size=[300,300],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
fix2 = visual.TextStim(win=win, name='fix2',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-2.0);
label = visual.TextStim(win=win, name='label',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, -0.05), height=0.04, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
risposta = keyboard.Keyboard()

# --- Initialize components for Routine "feedback" ---
# Run 'Begin Experiment' code from code
msg=' '
text_7 = visual.TextStim(win=win, name='text_7',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "inizio_blocco" ---
text_5 = visual.TextStim(win=win, name='text_5',
    text='練習は終わりました。\n\nこれから本番を開始します。本番では練習と同様の課題を行います。\n\nスペースバーを押して実験を開始します',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_2 = keyboard.Keyboard()

# --- Initialize components for Routine "trial" ---
fix = visual.TextStim(win=win, name='fix',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
image = visual.ImageStim(
    win=win,
    name='image', units='pix', 
    image='sin', mask=None, anchor='center',
    ori=0, pos=[0,180], size=[300,300],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
fix2 = visual.TextStim(win=win, name='fix2',
    text='+',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.05, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=1.0, 
    languageStyle='LTR',
    depth=-2.0);
label = visual.TextStim(win=win, name='label',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, -0.05), height=0.04, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-3.0);
risposta = keyboard.Keyboard()

# --- Initialize components for Routine "feedback" ---
# Run 'Begin Experiment' code from code
msg=' '
text_7 = visual.TextStim(win=win, name='text_7',
    text='',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# --- Initialize components for Routine "chiama_pausa_2" ---
text_11 = visual.TextStim(win=win, name='text_11',
    text='これで少し休憩できますが、PC から離れないでください。\n\nスペースバーを押して再開します。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.04, wrapWidth=None, ori=0.0, 
    color='black', colorSpace='rgb', opacity=None, 
    languageStyle='LTR',
    depth=0.0);
key_resp_7 = keyboard.Keyboard()

# --- Initialize components for Routine "fine_primo_blocco" ---
text_8 = visual.TextStim(win=win, name='text_8',
    text='最初の実験は終わりました。\n\n2 番目の実験は最初の実験と似ています。\n\nただし、2 番目の実験ではあなたは他の顔に関連付けられています。\n\n新しい関連付けを学習するには、スペース バーを押します。',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.03, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
key_resp_4 = keyboard.Keyboard()

# --- Initialize components for Routine "fine" ---
end_exp = visual.TextStim(win=win, name='end_exp',
    text='実験終了。\nありがとうございました！',
    font='Hiragino Kaku Gothic Pro W3',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='black', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.Clock()  # to track time remaining of each (possibly non-slip) routine 

# --- Prepare to start Routine "select_condition" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
# keep track of which components have finished
select_conditionComponents = []
for thisComponent in select_conditionComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "select_condition" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in select_conditionComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "select_condition" ---
for thisComponent in select_conditionComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "select_condition" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
istruct_pages = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('instructs.xlsx'),
    seed=None, name='istruct_pages')
thisExp.addLoop(istruct_pages)  # add the loop to the experiment
thisIstruct_page = istruct_pages.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisIstruct_page.rgb)
if thisIstruct_page != None:
    for paramName in thisIstruct_page:
        exec('{} = thisIstruct_page[paramName]'.format(paramName))

for thisIstruct_page in istruct_pages:
    currentLoop = istruct_pages
    # abbreviate parameter names if possible (e.g. rgb = thisIstruct_page.rgb)
    if thisIstruct_page != None:
        for paramName in thisIstruct_page:
            exec('{} = thisIstruct_page[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "instructions" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    instructs_text.setText(instruct_text)
    instruct_done.keys = []
    instruct_done.rt = []
    _instruct_done_allKeys = []
    # keep track of which components have finished
    instructionsComponents = [instructs_text, instruct_done, instr_done_button, instr_done_label]
    for thisComponent in instructionsComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "instructions" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *instructs_text* updates
        if instructs_text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instructs_text.frameNStart = frameN  # exact frame index
            instructs_text.tStart = t  # local t and not account for scr refresh
            instructs_text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instructs_text, 'tStartRefresh')  # time at next scr refresh
            instructs_text.setAutoDraw(True)
        
        # *instruct_done* updates
        waitOnFlip = False
        if instruct_done.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instruct_done.frameNStart = frameN  # exact frame index
            instruct_done.tStart = t  # local t and not account for scr refresh
            instruct_done.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instruct_done, 'tStartRefresh')  # time at next scr refresh
            instruct_done.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(instruct_done.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(instruct_done.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if instruct_done.status == STARTED and not waitOnFlip:
            theseKeys = instruct_done.getKeys(keyList=['space'], waitRelease=False)
            _instruct_done_allKeys.extend(theseKeys)
            if len(_instruct_done_allKeys):
                instruct_done.keys = _instruct_done_allKeys[-1].name  # just the last key pressed
                instruct_done.rt = _instruct_done_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # *instr_done_button* updates
        if instr_done_button.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instr_done_button.frameNStart = frameN  # exact frame index
            instr_done_button.tStart = t  # local t and not account for scr refresh
            instr_done_button.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instr_done_button, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instr_done_button.started')
            instr_done_button.setAutoDraw(True)
        
        # *instr_done_label* updates
        if instr_done_label.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            instr_done_label.frameNStart = frameN  # exact frame index
            instr_done_label.tStart = t  # local t and not account for scr refresh
            instr_done_label.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(instr_done_label, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'instr_done_label.started')
            instr_done_label.setAutoDraw(True)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in instructionsComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "instructions" ---
    for thisComponent in instructionsComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # Run 'End Routine' code from hide_mouse_2
    win.mouseVisible = False
    # the Routine "instructions" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'istruct_pages'


# set up handler to look after randomisation of conditions etc
blocks_iat = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions(blocks_file),
    seed=None, name='blocks_iat')
thisExp.addLoop(blocks_iat)  # add the loop to the experiment
thisBlocks_iat = blocks_iat.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisBlocks_iat.rgb)
if thisBlocks_iat != None:
    for paramName in thisBlocks_iat:
        exec('{} = thisBlocks_iat[paramName]'.format(paramName))

for thisBlocks_iat in blocks_iat:
    currentLoop = blocks_iat
    # abbreviate parameter names if possible (e.g. rgb = thisBlocks_iat.rgb)
    if thisBlocks_iat != None:
        for paramName in thisBlocks_iat:
            exec('{} = thisBlocks_iat[paramName]'.format(paramName))
    
    # --- Prepare to start Routine "ready" ---
    continueRoutine = True
    routineForceEnded = False
    # update component parameters for each repeat
    ready_label_L.setText(label_left)
    ready_label_R.setText(label_right)
    ready_done.keys = []
    ready_done.rt = []
    _ready_done_allKeys = []
    # keep track of which components have finished
    readyComponents = [main_ready_msg, button_L, ready_label_L, button_R, ready_label_R, ready_done]
    for thisComponent in readyComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    frameN = -1
    
    # --- Run Routine "ready" ---
    while continueRoutine:
        # get current time
        t = routineTimer.getTime()
        tThisFlip = win.getFutureFlipTime(clock=routineTimer)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *main_ready_msg* updates
        if main_ready_msg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            main_ready_msg.frameNStart = frameN  # exact frame index
            main_ready_msg.tStart = t  # local t and not account for scr refresh
            main_ready_msg.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(main_ready_msg, 'tStartRefresh')  # time at next scr refresh
            main_ready_msg.setAutoDraw(True)
        
        # *button_L* updates
        if button_L.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            button_L.frameNStart = frameN  # exact frame index
            button_L.tStart = t  # local t and not account for scr refresh
            button_L.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(button_L, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'button_L.started')
            button_L.setAutoDraw(True)
        
        # *ready_label_L* updates
        if ready_label_L.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ready_label_L.frameNStart = frameN  # exact frame index
            ready_label_L.tStart = t  # local t and not account for scr refresh
            ready_label_L.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ready_label_L, 'tStartRefresh')  # time at next scr refresh
            ready_label_L.setAutoDraw(True)
        
        # *button_R* updates
        if button_R.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            button_R.frameNStart = frameN  # exact frame index
            button_R.tStart = t  # local t and not account for scr refresh
            button_R.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(button_R, 'tStartRefresh')  # time at next scr refresh
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'button_R.started')
            button_R.setAutoDraw(True)
        
        # *ready_label_R* updates
        if ready_label_R.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ready_label_R.frameNStart = frameN  # exact frame index
            ready_label_R.tStart = t  # local t and not account for scr refresh
            ready_label_R.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ready_label_R, 'tStartRefresh')  # time at next scr refresh
            ready_label_R.setAutoDraw(True)
        
        # *ready_done* updates
        waitOnFlip = False
        if ready_done.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ready_done.frameNStart = frameN  # exact frame index
            ready_done.tStart = t  # local t and not account for scr refresh
            ready_done.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ready_done, 'tStartRefresh')  # time at next scr refresh
            ready_done.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(ready_done.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(ready_done.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if ready_done.status == STARTED and not waitOnFlip:
            theseKeys = ready_done.getKeys(keyList=['space'], waitRelease=False)
            _ready_done_allKeys.extend(theseKeys)
            if len(_ready_done_allKeys):
                ready_done.keys = _ready_done_allKeys[-1].name  # just the last key pressed
                ready_done.rt = _ready_done_allKeys[-1].rt
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            routineForceEnded = True
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in readyComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # --- Ending Routine "ready" ---
    for thisComponent in readyComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    # the Routine "ready" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    trials_iat = data.TrialHandler(nReps=1.0, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=data.importConditions(conds_file),
        seed=None, name='trials_iat')
    thisExp.addLoop(trials_iat)  # add the loop to the experiment
    thisTrials_iat = trials_iat.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_iat.rgb)
    if thisTrials_iat != None:
        for paramName in thisTrials_iat:
            exec('{} = thisTrials_iat[paramName]'.format(paramName))
    
    for thisTrials_iat in trials_iat:
        currentLoop = trials_iat
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_iat.rgb)
        if thisTrials_iat != None:
            for paramName in thisTrials_iat:
                exec('{} = thisTrials_iat[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "trial_iat" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        text_stim.setText(stimWord)
        image_stim.setImage(stimImage)
        key_resp_iat.keys = []
        key_resp_iat.rt = []
        _key_resp_iat_allKeys = []
        trial_label_left.setText(label_left)
        trial_label_right.setText(label_right)
        # keep track of which components have finished
        trial_iatComponents = [fixation, text_stim, image_stim, key_resp_iat, button_left, trial_label_left, button_right, trial_label_right]
        for thisComponent in trial_iatComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "trial_iat" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *fixation* updates
            if fixation.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                fixation.frameNStart = frameN  # exact frame index
                fixation.tStart = t  # local t and not account for scr refresh
                fixation.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(fixation, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'fixation.started')
                fixation.setAutoDraw(True)
            if fixation.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > fixation.tStartRefresh + 0.5-frameTolerance:
                    # keep track of stop time/frame for later
                    fixation.tStop = t  # not accounting for scr refresh
                    fixation.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fixation.stopped')
                    fixation.setAutoDraw(False)
            
            # *text_stim* updates
            if text_stim.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                text_stim.frameNStart = frameN  # exact frame index
                text_stim.tStart = t  # local t and not account for scr refresh
                text_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_stim.started')
                text_stim.setAutoDraw(True)
            
            # *image_stim* updates
            if image_stim.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                image_stim.frameNStart = frameN  # exact frame index
                image_stim.tStart = t  # local t and not account for scr refresh
                image_stim.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(image_stim, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'image_stim.started')
                image_stim.setAutoDraw(True)
            
            # *key_resp_iat* updates
            waitOnFlip = False
            if key_resp_iat.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                key_resp_iat.frameNStart = frameN  # exact frame index
                key_resp_iat.tStart = t  # local t and not account for scr refresh
                key_resp_iat.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_iat, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_iat.started')
                key_resp_iat.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_iat.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_iat.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_iat.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_iat.getKeys(keyList=['a','l'], waitRelease=False)
                _key_resp_iat_allKeys.extend(theseKeys)
                if len(_key_resp_iat_allKeys):
                    key_resp_iat.keys = _key_resp_iat_allKeys[-1].name  # just the last key pressed
                    key_resp_iat.rt = _key_resp_iat_allKeys[-1].rt
                    # was this correct?
                    if (key_resp_iat.keys == str(CorrAns)) or (key_resp_iat.keys == CorrAns):
                        key_resp_iat.corr = 1
                    else:
                        key_resp_iat.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # *button_left* updates
            if button_left.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                button_left.frameNStart = frameN  # exact frame index
                button_left.tStart = t  # local t and not account for scr refresh
                button_left.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(button_left, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'button_left.started')
                button_left.setAutoDraw(True)
            
            # *trial_label_left* updates
            if trial_label_left.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                trial_label_left.frameNStart = frameN  # exact frame index
                trial_label_left.tStart = t  # local t and not account for scr refresh
                trial_label_left.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(trial_label_left, 'tStartRefresh')  # time at next scr refresh
                trial_label_left.setAutoDraw(True)
            
            # *button_right* updates
            if button_right.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                button_right.frameNStart = frameN  # exact frame index
                button_right.tStart = t  # local t and not account for scr refresh
                button_right.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(button_right, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'button_right.started')
                button_right.setAutoDraw(True)
            
            # *trial_label_right* updates
            if trial_label_right.status == NOT_STARTED and tThisFlip >= 0.5-frameTolerance:
                # keep track of start time/frame for later
                trial_label_right.frameNStart = frameN  # exact frame index
                trial_label_right.tStart = t  # local t and not account for scr refresh
                trial_label_right.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(trial_label_right, 'tStartRefresh')  # time at next scr refresh
                trial_label_right.setAutoDraw(True)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in trial_iatComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "trial_iat" ---
        for thisComponent in trial_iatComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if key_resp_iat.keys in ['', [], None]:  # No response was made
            key_resp_iat.keys = None
            # was no response the correct answer?!
            if str(CorrAns).lower() == 'none':
               key_resp_iat.corr = 1;  # correct non-response
            else:
               key_resp_iat.corr = 0;  # failed to respond (incorrectly)
        # store data for trials_iat (TrialHandler)
        trials_iat.addData('key_resp_iat.keys',key_resp_iat.keys)
        trials_iat.addData('key_resp_iat.corr', key_resp_iat.corr)
        if key_resp_iat.keys != None:  # we had a response
            trials_iat.addData('key_resp_iat.rt', key_resp_iat.rt)
        # Run 'End Routine' code from check_correct
        # check if correct (either mouse or keyboard)
        if key_resp_iat.keys:
            corr = key_resp_iat.corr
            rt = key_resp_iat.rt
        else:
            rt = touch_resp.time[0]  # annoyingly mouse is a list of rts
            if (('left' in touch_resp.clicked_name[0] and CorrAns=='a') or
                ('right' in touch_resp.clicked_name[0] and CorrAns=='l')):
                corr = 1
            else:
                corr = 0
        
        thisExp.addData('rt',  rt)
        thisExp.addData('corr', corr)
        # the Routine "trial_iat" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # --- Prepare to start Routine "feedback_iat" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        # Run 'Begin Routine' code from generate_msg
        
        if corr==0:
            msg="!!!"
        else:
            msg="OK"
        feedback_msg.setText(msg)
        # keep track of which components have finished
        feedback_iatComponents = [feedback_msg]
        for thisComponent in feedback_iatComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "feedback_iat" ---
        while continueRoutine and routineTimer.getTime() < 1.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *feedback_msg* updates
            if feedback_msg.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                feedback_msg.frameNStart = frameN  # exact frame index
                feedback_msg.tStart = t  # local t and not account for scr refresh
                feedback_msg.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(feedback_msg, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'feedback_msg.started')
                feedback_msg.setAutoDraw(True)
            if feedback_msg.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > feedback_msg.tStartRefresh + 1.0-frameTolerance:
                    # keep track of stop time/frame for later
                    feedback_msg.tStop = t  # not accounting for scr refresh
                    feedback_msg.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'feedback_msg.stopped')
                    feedback_msg.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in feedback_iatComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "feedback_iat" ---
        for thisComponent in feedback_iatComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-1.000000)
        thisExp.nextEntry()
        
    # completed 1.0 repeats of 'trials_iat'
    
# completed 1.0 repeats of 'blocks_iat'


# --- Prepare to start Routine "start_self" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
key_resp_14.keys = []
key_resp_14.rt = []
_key_resp_14_allKeys = []
# keep track of which components have finished
start_selfComponents = [text_18, key_resp_14]
for thisComponent in start_selfComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "start_self" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_18* updates
    if text_18.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_18.frameNStart = frameN  # exact frame index
        text_18.tStart = t  # local t and not account for scr refresh
        text_18.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_18, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'text_18.started')
        text_18.setAutoDraw(True)
    
    # *key_resp_14* updates
    waitOnFlip = False
    if key_resp_14.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
        # keep track of start time/frame for later
        key_resp_14.frameNStart = frameN  # exact frame index
        key_resp_14.tStart = t  # local t and not account for scr refresh
        key_resp_14.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp_14, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'key_resp_14.started')
        key_resp_14.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp_14.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp_14.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp_14.status == STARTED and not waitOnFlip:
        theseKeys = key_resp_14.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_14_allKeys.extend(theseKeys)
        if len(_key_resp_14_allKeys):
            key_resp_14.keys = _key_resp_14_allKeys[-1].name  # just the last key pressed
            key_resp_14.rt = _key_resp_14_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in start_selfComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "start_self" ---
for thisComponent in start_selfComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp_14.keys in ['', [], None]:  # No response was made
    key_resp_14.keys = None
thisExp.addData('key_resp_14.keys',key_resp_14.keys)
if key_resp_14.keys != None:  # we had a response
    thisExp.addData('key_resp_14.rt', key_resp_14.rt)
thisExp.nextEntry()
# the Routine "start_self" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# --- Prepare to start Routine "intro" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
key_resp.keys = []
key_resp.rt = []
_key_resp_allKeys = []
# Run 'Begin Routine' code from hide_mouse
win.mouseVisible = True
# keep track of which components have finished
introComponents = [text_2, key_resp]
for thisComponent in introComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "intro" ---
while continueRoutine:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *text_2* updates
    if text_2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        text_2.frameNStart = frameN  # exact frame index
        text_2.tStart = t  # local t and not account for scr refresh
        text_2.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(text_2, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'text_2.started')
        text_2.setAutoDraw(True)
    
    # *key_resp* updates
    waitOnFlip = False
    if key_resp.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
        # keep track of start time/frame for later
        key_resp.frameNStart = frameN  # exact frame index
        key_resp.tStart = t  # local t and not account for scr refresh
        key_resp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(key_resp, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'key_resp.started')
        key_resp.status = STARTED
        # keyboard checking is just starting
        waitOnFlip = True
        win.callOnFlip(key_resp.clock.reset)  # t=0 on next screen flip
        win.callOnFlip(key_resp.clearEvents, eventType='keyboard')  # clear events on next screen flip
    if key_resp.status == STARTED and not waitOnFlip:
        theseKeys = key_resp.getKeys(keyList=['space'], waitRelease=False)
        _key_resp_allKeys.extend(theseKeys)
        if len(_key_resp_allKeys):
            key_resp.keys = _key_resp_allKeys[-1].name  # just the last key pressed
            key_resp.rt = _key_resp_allKeys[-1].rt
            # a response ends the routine
            continueRoutine = False
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in introComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "intro" ---
for thisComponent in introComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# check responses
if key_resp.keys in ['', [], None]:  # No response was made
    key_resp.keys = None
thisExp.addData('key_resp.keys',key_resp.keys)
if key_resp.keys != None:  # we had a response
    thisExp.addData('key_resp.rt', key_resp.rt)
thisExp.nextEntry()
# Run 'End Routine' code from hide_mouse
win.mouseVisible = False
# the Routine "intro" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
controlTaskOrder = data.TrialHandler(nReps=1.0, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('conditions'+str(Cond_code)+'.xlsx'),
    seed=None, name='controlTaskOrder')
thisExp.addLoop(controlTaskOrder)  # add the loop to the experiment
thisControlTaskOrder = controlTaskOrder.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb = thisControlTaskOrder.rgb)
if thisControlTaskOrder != None:
    for paramName in thisControlTaskOrder:
        exec('{} = thisControlTaskOrder[paramName]'.format(paramName))

for thisControlTaskOrder in controlTaskOrder:
    currentLoop = controlTaskOrder
    # abbreviate parameter names if possible (e.g. rgb = thisControlTaskOrder.rgb)
    if thisControlTaskOrder != None:
        for paramName in thisControlTaskOrder:
            exec('{} = thisControlTaskOrder[paramName]'.format(paramName))
    
    # set up handler to look after randomisation of conditions etc
    trials_w = data.TrialHandler(nReps=nRepsTask1, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_w')
    thisExp.addLoop(trials_w)  # add the loop to the experiment
    thisTrials_w = trials_w.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_w.rgb)
    if thisTrials_w != None:
        for paramName in thisTrials_w:
            exec('{} = thisTrials_w[paramName]'.format(paramName))
    
    for thisTrials_w in trials_w:
        currentLoop = trials_w
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_w.rgb)
        if thisTrials_w != None:
            for paramName in thisTrials_w:
                exec('{} = thisTrials_w[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "associazione_w" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        # keep track of which components have finished
        associazione_wComponents = [text_3]
        for thisComponent in associazione_wComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "associazione_w" ---
        while continueRoutine and routineTimer.getTime() < 40.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_3* updates
            if text_3.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_3.frameNStart = frameN  # exact frame index
                text_3.tStart = t  # local t and not account for scr refresh
                text_3.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_3, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_3.started')
                text_3.setAutoDraw(True)
            if text_3.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_3.tStartRefresh + 40-frameTolerance:
                    # keep track of stop time/frame for later
                    text_3.tStop = t  # not accounting for scr refresh
                    text_3.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_3.stopped')
                    text_3.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in associazione_wComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "associazione_w" ---
        for thisComponent in associazione_wComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-40.000000)
        
        # set up handler to look after randomisation of conditions etc
        trial_istr_w_a1 = data.TrialHandler(nReps=nIstrWA1, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trial_istr_w_a1')
        thisExp.addLoop(trial_istr_w_a1)  # add the loop to the experiment
        thisTrial_istr_w_a1 = trial_istr_w_a1.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_w_a1.rgb)
        if thisTrial_istr_w_a1 != None:
            for paramName in thisTrial_istr_w_a1:
                exec('{} = thisTrial_istr_w_a1[paramName]'.format(paramName))
        
        for thisTrial_istr_w_a1 in trial_istr_w_a1:
            currentLoop = trial_istr_w_a1
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_w_a1.rgb)
            if thisTrial_istr_w_a1 != None:
                for paramName in thisTrial_istr_w_a1:
                    exec('{} = thisTrial_istr_w_a1[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "istruzioni_w_a1" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_3.keys = []
            key_resp_3.rt = []
            _key_resp_3_allKeys = []
            # keep track of which components have finished
            istruzioni_w_a1Components = [text_6, key_resp_3]
            for thisComponent in istruzioni_w_a1Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "istruzioni_w_a1" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_6* updates
                if text_6.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_6.frameNStart = frameN  # exact frame index
                    text_6.tStart = t  # local t and not account for scr refresh
                    text_6.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_6, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_6.started')
                    text_6.setAutoDraw(True)
                
                # *key_resp_3* updates
                waitOnFlip = False
                if key_resp_3.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_3.frameNStart = frameN  # exact frame index
                    key_resp_3.tStart = t  # local t and not account for scr refresh
                    key_resp_3.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_3, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_3.started')
                    key_resp_3.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_3.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_3.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_3.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_3.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_3_allKeys.extend(theseKeys)
                    if len(_key_resp_3_allKeys):
                        key_resp_3.keys = _key_resp_3_allKeys[-1].name  # just the last key pressed
                        key_resp_3.rt = _key_resp_3_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in istruzioni_w_a1Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "istruzioni_w_a1" ---
            for thisComponent in istruzioni_w_a1Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_3.keys in ['', [], None]:  # No response was made
                key_resp_3.keys = None
            trial_istr_w_a1.addData('key_resp_3.keys',key_resp_3.keys)
            if key_resp_3.keys != None:  # we had a response
                trial_istr_w_a1.addData('key_resp_3.rt', key_resp_3.rt)
            # the Routine "istruzioni_w_a1" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed nIstrWA1 repeats of 'trial_istr_w_a1'
        
        
        # set up handler to look after randomisation of conditions etc
        trial_istr_w_l1 = data.TrialHandler(nReps=nIstrWL1, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trial_istr_w_l1')
        thisExp.addLoop(trial_istr_w_l1)  # add the loop to the experiment
        thisTrial_istr_w_l1 = trial_istr_w_l1.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_w_l1.rgb)
        if thisTrial_istr_w_l1 != None:
            for paramName in thisTrial_istr_w_l1:
                exec('{} = thisTrial_istr_w_l1[paramName]'.format(paramName))
        
        for thisTrial_istr_w_l1 in trial_istr_w_l1:
            currentLoop = trial_istr_w_l1
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_w_l1.rgb)
            if thisTrial_istr_w_l1 != None:
                for paramName in thisTrial_istr_w_l1:
                    exec('{} = thisTrial_istr_w_l1[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "istruzioni_w_l1" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_8.keys = []
            key_resp_8.rt = []
            _key_resp_8_allKeys = []
            # keep track of which components have finished
            istruzioni_w_l1Components = [text_12, key_resp_8]
            for thisComponent in istruzioni_w_l1Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "istruzioni_w_l1" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_12* updates
                if text_12.status == NOT_STARTED and tThisFlip >= 0-frameTolerance:
                    # keep track of start time/frame for later
                    text_12.frameNStart = frameN  # exact frame index
                    text_12.tStart = t  # local t and not account for scr refresh
                    text_12.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_12, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_12.started')
                    text_12.setAutoDraw(True)
                
                # *key_resp_8* updates
                waitOnFlip = False
                if key_resp_8.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_8.frameNStart = frameN  # exact frame index
                    key_resp_8.tStart = t  # local t and not account for scr refresh
                    key_resp_8.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_8, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_8.started')
                    key_resp_8.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_8.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_8.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_8.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_8.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_8_allKeys.extend(theseKeys)
                    if len(_key_resp_8_allKeys):
                        key_resp_8.keys = _key_resp_8_allKeys[-1].name  # just the last key pressed
                        key_resp_8.rt = _key_resp_8_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in istruzioni_w_l1Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "istruzioni_w_l1" ---
            for thisComponent in istruzioni_w_l1Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_8.keys in ['', [], None]:  # No response was made
                key_resp_8.keys = None
            trial_istr_w_l1.addData('key_resp_8.keys',key_resp_8.keys)
            if key_resp_8.keys != None:  # we had a response
                trial_istr_w_l1.addData('key_resp_8.rt', key_resp_8.rt)
            # the Routine "istruzioni_w_l1" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed nIstrWL1 repeats of 'trial_istr_w_l1'
        
        
        # set up handler to look after randomisation of conditions etc
        trial_istr_w_a2 = data.TrialHandler(nReps=nIstrWA2, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trial_istr_w_a2')
        thisExp.addLoop(trial_istr_w_a2)  # add the loop to the experiment
        thisTrial_istr_w_a2 = trial_istr_w_a2.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_w_a2.rgb)
        if thisTrial_istr_w_a2 != None:
            for paramName in thisTrial_istr_w_a2:
                exec('{} = thisTrial_istr_w_a2[paramName]'.format(paramName))
        
        for thisTrial_istr_w_a2 in trial_istr_w_a2:
            currentLoop = trial_istr_w_a2
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_w_a2.rgb)
            if thisTrial_istr_w_a2 != None:
                for paramName in thisTrial_istr_w_a2:
                    exec('{} = thisTrial_istr_w_a2[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "istruzioni_w_a2" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_10.keys = []
            key_resp_10.rt = []
            _key_resp_10_allKeys = []
            # keep track of which components have finished
            istruzioni_w_a2Components = [text_14, key_resp_10]
            for thisComponent in istruzioni_w_a2Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "istruzioni_w_a2" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_14* updates
                if text_14.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_14.frameNStart = frameN  # exact frame index
                    text_14.tStart = t  # local t and not account for scr refresh
                    text_14.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_14, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_14.started')
                    text_14.setAutoDraw(True)
                
                # *key_resp_10* updates
                waitOnFlip = False
                if key_resp_10.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_10.frameNStart = frameN  # exact frame index
                    key_resp_10.tStart = t  # local t and not account for scr refresh
                    key_resp_10.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_10, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_10.started')
                    key_resp_10.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_10.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_10.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_10.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_10.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_10_allKeys.extend(theseKeys)
                    if len(_key_resp_10_allKeys):
                        key_resp_10.keys = _key_resp_10_allKeys[-1].name  # just the last key pressed
                        key_resp_10.rt = _key_resp_10_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in istruzioni_w_a2Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "istruzioni_w_a2" ---
            for thisComponent in istruzioni_w_a2Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_10.keys in ['', [], None]:  # No response was made
                key_resp_10.keys = None
            trial_istr_w_a2.addData('key_resp_10.keys',key_resp_10.keys)
            if key_resp_10.keys != None:  # we had a response
                trial_istr_w_a2.addData('key_resp_10.rt', key_resp_10.rt)
            # the Routine "istruzioni_w_a2" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed nIstrWA2 repeats of 'trial_istr_w_a2'
        
        
        # set up handler to look after randomisation of conditions etc
        trial_istr_w_l2 = data.TrialHandler(nReps=nIstrWL2, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trial_istr_w_l2')
        thisExp.addLoop(trial_istr_w_l2)  # add the loop to the experiment
        thisTrial_istr_w_l2 = trial_istr_w_l2.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_w_l2.rgb)
        if thisTrial_istr_w_l2 != None:
            for paramName in thisTrial_istr_w_l2:
                exec('{} = thisTrial_istr_w_l2[paramName]'.format(paramName))
        
        for thisTrial_istr_w_l2 in trial_istr_w_l2:
            currentLoop = trial_istr_w_l2
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_w_l2.rgb)
            if thisTrial_istr_w_l2 != None:
                for paramName in thisTrial_istr_w_l2:
                    exec('{} = thisTrial_istr_w_l2[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "istruzioni_w_l2" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_11.keys = []
            key_resp_11.rt = []
            _key_resp_11_allKeys = []
            # keep track of which components have finished
            istruzioni_w_l2Components = [text_15, key_resp_11]
            for thisComponent in istruzioni_w_l2Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "istruzioni_w_l2" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_15* updates
                if text_15.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_15.frameNStart = frameN  # exact frame index
                    text_15.tStart = t  # local t and not account for scr refresh
                    text_15.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_15, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_15.started')
                    text_15.setAutoDraw(True)
                
                # *key_resp_11* updates
                waitOnFlip = False
                if key_resp_11.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_11.frameNStart = frameN  # exact frame index
                    key_resp_11.tStart = t  # local t and not account for scr refresh
                    key_resp_11.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_11, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_11.started')
                    key_resp_11.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_11.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_11.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_11.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_11.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_11_allKeys.extend(theseKeys)
                    if len(_key_resp_11_allKeys):
                        key_resp_11.keys = _key_resp_11_allKeys[-1].name  # just the last key pressed
                        key_resp_11.rt = _key_resp_11_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in istruzioni_w_l2Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "istruzioni_w_l2" ---
            for thisComponent in istruzioni_w_l2Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_11.keys in ['', [], None]:  # No response was made
                key_resp_11.keys = None
            trial_istr_w_l2.addData('key_resp_11.keys',key_resp_11.keys)
            if key_resp_11.keys != None:  # we had a response
                trial_istr_w_l2.addData('key_resp_11.rt', key_resp_11.rt)
            # the Routine "istruzioni_w_l2" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed nIstrWL2 repeats of 'trial_istr_w_l2'
        
        
        # set up handler to look after randomisation of conditions etc
        prova_w = data.TrialHandler(nReps=1, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('wp'+expInfo['sex']+str(Cond_code)+'.xlsx'),
            seed=None, name='prova_w')
        thisExp.addLoop(prova_w)  # add the loop to the experiment
        thisProva_w = prova_w.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisProva_w.rgb)
        if thisProva_w != None:
            for paramName in thisProva_w:
                exec('{} = thisProva_w[paramName]'.format(paramName))
        
        for thisProva_w in prova_w:
            currentLoop = prova_w
            # abbreviate parameter names if possible (e.g. rgb = thisProva_w.rgb)
            if thisProva_w != None:
                for paramName in thisProva_w:
                    exec('{} = thisProva_w[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "trial" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            image.setImage(file_stim)
            label.setText(etichetta)
            risposta.keys = []
            risposta.rt = []
            _risposta_allKeys = []
            # keep track of which components have finished
            trialComponents = [fix, image, fix2, label, risposta]
            for thisComponent in trialComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "trial" ---
            while continueRoutine and routineTimer.getTime() < 1.6:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *fix* updates
                if fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fix.frameNStart = frameN  # exact frame index
                    fix.tStart = t  # local t and not account for scr refresh
                    fix.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fix, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix.started')
                    fix.setAutoDraw(True)
                if fix.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fix.tStartRefresh + 0.6-frameTolerance:
                        # keep track of stop time/frame for later
                        fix.tStop = t  # not accounting for scr refresh
                        fix.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fix.stopped')
                        fix.setAutoDraw(False)
                
                # *image* updates
                if image.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    image.frameNStart = frameN  # exact frame index
                    image.tStart = t  # local t and not account for scr refresh
                    image.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image.started')
                    image.setAutoDraw(True)
                if image.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image.tStartRefresh + 0.2-frameTolerance:
                        # keep track of stop time/frame for later
                        image.tStop = t  # not accounting for scr refresh
                        image.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image.stopped')
                        image.setAutoDraw(False)
                
                # *fix2* updates
                if fix2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fix2.frameNStart = frameN  # exact frame index
                    fix2.tStart = t  # local t and not account for scr refresh
                    fix2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fix2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix2.started')
                    fix2.setAutoDraw(True)
                if fix2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fix2.tStartRefresh + 0.6-frameTolerance:
                        # keep track of stop time/frame for later
                        fix2.tStop = t  # not accounting for scr refresh
                        fix2.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fix2.stopped')
                        fix2.setAutoDraw(False)
                
                # *label* updates
                if label.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    label.frameNStart = frameN  # exact frame index
                    label.tStart = t  # local t and not account for scr refresh
                    label.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(label, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'label.started')
                    label.setAutoDraw(True)
                if label.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > label.tStartRefresh + 0.2-frameTolerance:
                        # keep track of stop time/frame for later
                        label.tStop = t  # not accounting for scr refresh
                        label.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'label.stopped')
                        label.setAutoDraw(False)
                
                # *risposta* updates
                waitOnFlip = False
                if risposta.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    risposta.frameNStart = frameN  # exact frame index
                    risposta.tStart = t  # local t and not account for scr refresh
                    risposta.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(risposta, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'risposta.started')
                    risposta.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(risposta.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(risposta.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if risposta.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > risposta.tStartRefresh + 1.2-frameTolerance:
                        # keep track of stop time/frame for later
                        risposta.tStop = t  # not accounting for scr refresh
                        risposta.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'risposta.stopped')
                        risposta.status = FINISHED
                if risposta.status == STARTED and not waitOnFlip:
                    theseKeys = risposta.getKeys(keyList=['a','l'], waitRelease=False)
                    _risposta_allKeys.extend(theseKeys)
                    if len(_risposta_allKeys):
                        risposta.keys = _risposta_allKeys[-1].name  # just the last key pressed
                        risposta.rt = _risposta_allKeys[-1].rt
                        # was this correct?
                        if (risposta.keys == str(corretto)) or (risposta.keys == corretto):
                            risposta.corr = 1
                        else:
                            risposta.corr = 0
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in trialComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "trial" ---
            for thisComponent in trialComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if risposta.keys in ['', [], None]:  # No response was made
                risposta.keys = None
                # was no response the correct answer?!
                if str(corretto).lower() == 'none':
                   risposta.corr = 1;  # correct non-response
                else:
                   risposta.corr = 0;  # failed to respond (incorrectly)
            # store data for prova_w (TrialHandler)
            prova_w.addData('risposta.keys',risposta.keys)
            prova_w.addData('risposta.corr', risposta.corr)
            if risposta.keys != None:  # we had a response
                prova_w.addData('risposta.rt', risposta.rt)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.600000)
            
            # --- Prepare to start Routine "feedback" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            # Run 'Begin Routine' code from code
            if not risposta.keys:
                msg='!!!'
            elif risposta.corr == 1:
                msg='!!!'
            else:
                msg='OK'
            text_7.setText(msg)
            # keep track of which components have finished
            feedbackComponents = [text_7]
            for thisComponent in feedbackComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "feedback" ---
            while continueRoutine and routineTimer.getTime() < 0.5:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_7* updates
                if text_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_7.frameNStart = frameN  # exact frame index
                    text_7.tStart = t  # local t and not account for scr refresh
                    text_7.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_7, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_7.started')
                    text_7.setAutoDraw(True)
                if text_7.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > text_7.tStartRefresh + 0.5-frameTolerance:
                        # keep track of stop time/frame for later
                        text_7.tStop = t  # not accounting for scr refresh
                        text_7.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'text_7.stopped')
                        text_7.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "feedback" ---
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-0.500000)
            thisExp.nextEntry()
            
        # completed 1 repeats of 'prova_w'
        
        
        # --- Prepare to start Routine "inizio_blocco" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        key_resp_2.keys = []
        key_resp_2.rt = []
        _key_resp_2_allKeys = []
        # keep track of which components have finished
        inizio_bloccoComponents = [text_5, key_resp_2]
        for thisComponent in inizio_bloccoComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "inizio_blocco" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_5* updates
            if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_5.frameNStart = frameN  # exact frame index
                text_5.tStart = t  # local t and not account for scr refresh
                text_5.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_5.started')
                text_5.setAutoDraw(True)
            
            # *key_resp_2* updates
            waitOnFlip = False
            if key_resp_2.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                # keep track of start time/frame for later
                key_resp_2.frameNStart = frameN  # exact frame index
                key_resp_2.tStart = t  # local t and not account for scr refresh
                key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_2.started')
                key_resp_2.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_2.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_2.getKeys(keyList=['space'], waitRelease=False)
                _key_resp_2_allKeys.extend(theseKeys)
                if len(_key_resp_2_allKeys):
                    key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
                    key_resp_2.rt = _key_resp_2_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in inizio_bloccoComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "inizio_blocco" ---
        for thisComponent in inizio_bloccoComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if key_resp_2.keys in ['', [], None]:  # No response was made
            key_resp_2.keys = None
        trials_w.addData('key_resp_2.keys',key_resp_2.keys)
        if key_resp_2.keys != None:  # we had a response
            trials_w.addData('key_resp_2.rt', key_resp_2.rt)
        # the Routine "inizio_blocco" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        blocco_w = data.TrialHandler(nReps=1, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('w'+expInfo['sex']+str(Cond_code)+'.xlsx'),
            seed=None, name='blocco_w')
        thisExp.addLoop(blocco_w)  # add the loop to the experiment
        thisBlocco_w = blocco_w.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisBlocco_w.rgb)
        if thisBlocco_w != None:
            for paramName in thisBlocco_w:
                exec('{} = thisBlocco_w[paramName]'.format(paramName))
        
        for thisBlocco_w in blocco_w:
            currentLoop = blocco_w
            # abbreviate parameter names if possible (e.g. rgb = thisBlocco_w.rgb)
            if thisBlocco_w != None:
                for paramName in thisBlocco_w:
                    exec('{} = thisBlocco_w[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "trial" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            image.setImage(file_stim)
            label.setText(etichetta)
            risposta.keys = []
            risposta.rt = []
            _risposta_allKeys = []
            # keep track of which components have finished
            trialComponents = [fix, image, fix2, label, risposta]
            for thisComponent in trialComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "trial" ---
            while continueRoutine and routineTimer.getTime() < 1.6:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *fix* updates
                if fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fix.frameNStart = frameN  # exact frame index
                    fix.tStart = t  # local t and not account for scr refresh
                    fix.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fix, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix.started')
                    fix.setAutoDraw(True)
                if fix.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fix.tStartRefresh + 0.6-frameTolerance:
                        # keep track of stop time/frame for later
                        fix.tStop = t  # not accounting for scr refresh
                        fix.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fix.stopped')
                        fix.setAutoDraw(False)
                
                # *image* updates
                if image.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    image.frameNStart = frameN  # exact frame index
                    image.tStart = t  # local t and not account for scr refresh
                    image.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image.started')
                    image.setAutoDraw(True)
                if image.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image.tStartRefresh + 0.2-frameTolerance:
                        # keep track of stop time/frame for later
                        image.tStop = t  # not accounting for scr refresh
                        image.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image.stopped')
                        image.setAutoDraw(False)
                
                # *fix2* updates
                if fix2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fix2.frameNStart = frameN  # exact frame index
                    fix2.tStart = t  # local t and not account for scr refresh
                    fix2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fix2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix2.started')
                    fix2.setAutoDraw(True)
                if fix2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fix2.tStartRefresh + 0.6-frameTolerance:
                        # keep track of stop time/frame for later
                        fix2.tStop = t  # not accounting for scr refresh
                        fix2.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fix2.stopped')
                        fix2.setAutoDraw(False)
                
                # *label* updates
                if label.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    label.frameNStart = frameN  # exact frame index
                    label.tStart = t  # local t and not account for scr refresh
                    label.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(label, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'label.started')
                    label.setAutoDraw(True)
                if label.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > label.tStartRefresh + 0.2-frameTolerance:
                        # keep track of stop time/frame for later
                        label.tStop = t  # not accounting for scr refresh
                        label.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'label.stopped')
                        label.setAutoDraw(False)
                
                # *risposta* updates
                waitOnFlip = False
                if risposta.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    risposta.frameNStart = frameN  # exact frame index
                    risposta.tStart = t  # local t and not account for scr refresh
                    risposta.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(risposta, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'risposta.started')
                    risposta.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(risposta.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(risposta.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if risposta.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > risposta.tStartRefresh + 1.2-frameTolerance:
                        # keep track of stop time/frame for later
                        risposta.tStop = t  # not accounting for scr refresh
                        risposta.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'risposta.stopped')
                        risposta.status = FINISHED
                if risposta.status == STARTED and not waitOnFlip:
                    theseKeys = risposta.getKeys(keyList=['a','l'], waitRelease=False)
                    _risposta_allKeys.extend(theseKeys)
                    if len(_risposta_allKeys):
                        risposta.keys = _risposta_allKeys[-1].name  # just the last key pressed
                        risposta.rt = _risposta_allKeys[-1].rt
                        # was this correct?
                        if (risposta.keys == str(corretto)) or (risposta.keys == corretto):
                            risposta.corr = 1
                        else:
                            risposta.corr = 0
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in trialComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "trial" ---
            for thisComponent in trialComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if risposta.keys in ['', [], None]:  # No response was made
                risposta.keys = None
                # was no response the correct answer?!
                if str(corretto).lower() == 'none':
                   risposta.corr = 1;  # correct non-response
                else:
                   risposta.corr = 0;  # failed to respond (incorrectly)
            # store data for blocco_w (TrialHandler)
            blocco_w.addData('risposta.keys',risposta.keys)
            blocco_w.addData('risposta.corr', risposta.corr)
            if risposta.keys != None:  # we had a response
                blocco_w.addData('risposta.rt', risposta.rt)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.600000)
            
            # --- Prepare to start Routine "feedback" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            # Run 'Begin Routine' code from code
            if not risposta.keys:
                msg='!!!'
            elif risposta.corr == 1:
                msg='!!!'
            else:
                msg='OK'
            text_7.setText(msg)
            # keep track of which components have finished
            feedbackComponents = [text_7]
            for thisComponent in feedbackComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "feedback" ---
            while continueRoutine and routineTimer.getTime() < 0.5:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_7* updates
                if text_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_7.frameNStart = frameN  # exact frame index
                    text_7.tStart = t  # local t and not account for scr refresh
                    text_7.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_7, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_7.started')
                    text_7.setAutoDraw(True)
                if text_7.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > text_7.tStartRefresh + 0.5-frameTolerance:
                        # keep track of stop time/frame for later
                        text_7.tStop = t  # not accounting for scr refresh
                        text_7.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'text_7.stopped')
                        text_7.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "feedback" ---
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-0.500000)
            
            # --- Prepare to start Routine "chiama_pausa" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_6.keys = []
            key_resp_6.rt = []
            _key_resp_6_allKeys = []
            # Run 'Begin Routine' code from call_pause
            if blocco_w.thisN != 89:
                continueRoutine = False
            # keep track of which components have finished
            chiama_pausaComponents = [text_10, key_resp_6]
            for thisComponent in chiama_pausaComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "chiama_pausa" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_10* updates
                if text_10.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_10.frameNStart = frameN  # exact frame index
                    text_10.tStart = t  # local t and not account for scr refresh
                    text_10.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_10, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_10.started')
                    text_10.setAutoDraw(True)
                
                # *key_resp_6* updates
                waitOnFlip = False
                if key_resp_6.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_6.frameNStart = frameN  # exact frame index
                    key_resp_6.tStart = t  # local t and not account for scr refresh
                    key_resp_6.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_6, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_6.started')
                    key_resp_6.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_6.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_6.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_6.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_6.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_6_allKeys.extend(theseKeys)
                    if len(_key_resp_6_allKeys):
                        key_resp_6.keys = _key_resp_6_allKeys[-1].name  # just the last key pressed
                        key_resp_6.rt = _key_resp_6_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in chiama_pausaComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "chiama_pausa" ---
            for thisComponent in chiama_pausaComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_6.keys in ['', [], None]:  # No response was made
                key_resp_6.keys = None
            blocco_w.addData('key_resp_6.keys',key_resp_6.keys)
            if key_resp_6.keys != None:  # we had a response
                blocco_w.addData('key_resp_6.rt', key_resp_6.rt)
            # the Routine "chiama_pausa" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed 1 repeats of 'blocco_w'
        
        thisExp.nextEntry()
        
    # completed nRepsTask1 repeats of 'trials_w'
    
    
    # set up handler to look after randomisation of conditions etc
    trials_a = data.TrialHandler(nReps=nRepsTask2, method='random', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trials_a')
    thisExp.addLoop(trials_a)  # add the loop to the experiment
    thisTrials_a = trials_a.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrials_a.rgb)
    if thisTrials_a != None:
        for paramName in thisTrials_a:
            exec('{} = thisTrials_a[paramName]'.format(paramName))
    
    for thisTrials_a in trials_a:
        currentLoop = trials_a
        # abbreviate parameter names if possible (e.g. rgb = thisTrials_a.rgb)
        if thisTrials_a != None:
            for paramName in thisTrials_a:
                exec('{} = thisTrials_a[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "associazione_b" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        # keep track of which components have finished
        associazione_bComponents = [text_4]
        for thisComponent in associazione_bComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "associazione_b" ---
        while continueRoutine and routineTimer.getTime() < 40.0:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_4* updates
            if text_4.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_4.frameNStart = frameN  # exact frame index
                text_4.tStart = t  # local t and not account for scr refresh
                text_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_4, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_4.started')
                text_4.setAutoDraw(True)
            if text_4.status == STARTED:
                # is it time to stop? (based on global clock, using actual start)
                if tThisFlipGlobal > text_4.tStartRefresh + 40-frameTolerance:
                    # keep track of stop time/frame for later
                    text_4.tStop = t  # not accounting for scr refresh
                    text_4.frameNStop = frameN  # exact frame index
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_4.stopped')
                    text_4.setAutoDraw(False)
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in associazione_bComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "associazione_b" ---
        for thisComponent in associazione_bComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
        if routineForceEnded:
            routineTimer.reset()
        else:
            routineTimer.addTime(-40.000000)
        
        # set up handler to look after randomisation of conditions etc
        trial_istr_a_a1 = data.TrialHandler(nReps=nIstrAA1, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trial_istr_a_a1')
        thisExp.addLoop(trial_istr_a_a1)  # add the loop to the experiment
        thisTrial_istr_a_a1 = trial_istr_a_a1.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_a_a1.rgb)
        if thisTrial_istr_a_a1 != None:
            for paramName in thisTrial_istr_a_a1:
                exec('{} = thisTrial_istr_a_a1[paramName]'.format(paramName))
        
        for thisTrial_istr_a_a1 in trial_istr_a_a1:
            currentLoop = trial_istr_a_a1
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_a_a1.rgb)
            if thisTrial_istr_a_a1 != None:
                for paramName in thisTrial_istr_a_a1:
                    exec('{} = thisTrial_istr_a_a1[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "istruzioni_a_a1" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_12.keys = []
            key_resp_12.rt = []
            _key_resp_12_allKeys = []
            # keep track of which components have finished
            istruzioni_a_a1Components = [text_16, key_resp_12]
            for thisComponent in istruzioni_a_a1Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "istruzioni_a_a1" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_16* updates
                if text_16.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_16.frameNStart = frameN  # exact frame index
                    text_16.tStart = t  # local t and not account for scr refresh
                    text_16.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_16, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_16.started')
                    text_16.setAutoDraw(True)
                
                # *key_resp_12* updates
                waitOnFlip = False
                if key_resp_12.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_12.frameNStart = frameN  # exact frame index
                    key_resp_12.tStart = t  # local t and not account for scr refresh
                    key_resp_12.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_12, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_12.started')
                    key_resp_12.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_12.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_12.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_12.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_12.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_12_allKeys.extend(theseKeys)
                    if len(_key_resp_12_allKeys):
                        key_resp_12.keys = _key_resp_12_allKeys[-1].name  # just the last key pressed
                        key_resp_12.rt = _key_resp_12_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in istruzioni_a_a1Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "istruzioni_a_a1" ---
            for thisComponent in istruzioni_a_a1Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_12.keys in ['', [], None]:  # No response was made
                key_resp_12.keys = None
            trial_istr_a_a1.addData('key_resp_12.keys',key_resp_12.keys)
            if key_resp_12.keys != None:  # we had a response
                trial_istr_a_a1.addData('key_resp_12.rt', key_resp_12.rt)
            # the Routine "istruzioni_a_a1" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed nIstrAA1 repeats of 'trial_istr_a_a1'
        
        
        # set up handler to look after randomisation of conditions etc
        trial_istr_a_l1 = data.TrialHandler(nReps=nIstrAL1, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trial_istr_a_l1')
        thisExp.addLoop(trial_istr_a_l1)  # add the loop to the experiment
        thisTrial_istr_a_l1 = trial_istr_a_l1.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_a_l1.rgb)
        if thisTrial_istr_a_l1 != None:
            for paramName in thisTrial_istr_a_l1:
                exec('{} = thisTrial_istr_a_l1[paramName]'.format(paramName))
        
        for thisTrial_istr_a_l1 in trial_istr_a_l1:
            currentLoop = trial_istr_a_l1
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_a_l1.rgb)
            if thisTrial_istr_a_l1 != None:
                for paramName in thisTrial_istr_a_l1:
                    exec('{} = thisTrial_istr_a_l1[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "istruzioni_a_l1" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_13.keys = []
            key_resp_13.rt = []
            _key_resp_13_allKeys = []
            # keep track of which components have finished
            istruzioni_a_l1Components = [text_17, key_resp_13]
            for thisComponent in istruzioni_a_l1Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "istruzioni_a_l1" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_17* updates
                if text_17.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_17.frameNStart = frameN  # exact frame index
                    text_17.tStart = t  # local t and not account for scr refresh
                    text_17.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_17, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_17.started')
                    text_17.setAutoDraw(True)
                
                # *key_resp_13* updates
                waitOnFlip = False
                if key_resp_13.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_13.frameNStart = frameN  # exact frame index
                    key_resp_13.tStart = t  # local t and not account for scr refresh
                    key_resp_13.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_13, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_13.started')
                    key_resp_13.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_13.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_13.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_13.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_13.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_13_allKeys.extend(theseKeys)
                    if len(_key_resp_13_allKeys):
                        key_resp_13.keys = _key_resp_13_allKeys[-1].name  # just the last key pressed
                        key_resp_13.rt = _key_resp_13_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in istruzioni_a_l1Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "istruzioni_a_l1" ---
            for thisComponent in istruzioni_a_l1Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_13.keys in ['', [], None]:  # No response was made
                key_resp_13.keys = None
            trial_istr_a_l1.addData('key_resp_13.keys',key_resp_13.keys)
            if key_resp_13.keys != None:  # we had a response
                trial_istr_a_l1.addData('key_resp_13.rt', key_resp_13.rt)
            # the Routine "istruzioni_a_l1" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed nIstrAL1 repeats of 'trial_istr_a_l1'
        
        
        # set up handler to look after randomisation of conditions etc
        trial_istr_a_a2 = data.TrialHandler(nReps=nIstrAA2, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trial_istr_a_a2')
        thisExp.addLoop(trial_istr_a_a2)  # add the loop to the experiment
        thisTrial_istr_a_a2 = trial_istr_a_a2.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_a_a2.rgb)
        if thisTrial_istr_a_a2 != None:
            for paramName in thisTrial_istr_a_a2:
                exec('{} = thisTrial_istr_a_a2[paramName]'.format(paramName))
        
        for thisTrial_istr_a_a2 in trial_istr_a_a2:
            currentLoop = trial_istr_a_a2
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_a_a2.rgb)
            if thisTrial_istr_a_a2 != None:
                for paramName in thisTrial_istr_a_a2:
                    exec('{} = thisTrial_istr_a_a2[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "istruzioni_a_a2" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_5.keys = []
            key_resp_5.rt = []
            _key_resp_5_allKeys = []
            # keep track of which components have finished
            istruzioni_a_a2Components = [text_9, key_resp_5]
            for thisComponent in istruzioni_a_a2Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "istruzioni_a_a2" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_9* updates
                if text_9.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_9.frameNStart = frameN  # exact frame index
                    text_9.tStart = t  # local t and not account for scr refresh
                    text_9.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_9, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_9.started')
                    text_9.setAutoDraw(True)
                
                # *key_resp_5* updates
                waitOnFlip = False
                if key_resp_5.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_5.frameNStart = frameN  # exact frame index
                    key_resp_5.tStart = t  # local t and not account for scr refresh
                    key_resp_5.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_5, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_5.started')
                    key_resp_5.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_5.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_5.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_5.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_5.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_5_allKeys.extend(theseKeys)
                    if len(_key_resp_5_allKeys):
                        key_resp_5.keys = _key_resp_5_allKeys[-1].name  # just the last key pressed
                        key_resp_5.rt = _key_resp_5_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in istruzioni_a_a2Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "istruzioni_a_a2" ---
            for thisComponent in istruzioni_a_a2Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_5.keys in ['', [], None]:  # No response was made
                key_resp_5.keys = None
            trial_istr_a_a2.addData('key_resp_5.keys',key_resp_5.keys)
            if key_resp_5.keys != None:  # we had a response
                trial_istr_a_a2.addData('key_resp_5.rt', key_resp_5.rt)
            # the Routine "istruzioni_a_a2" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed nIstrAA2 repeats of 'trial_istr_a_a2'
        
        
        # set up handler to look after randomisation of conditions etc
        trial_istr_a_l2 = data.TrialHandler(nReps=nIstrAL2, method='sequential', 
            extraInfo=expInfo, originPath=-1,
            trialList=[None],
            seed=None, name='trial_istr_a_l2')
        thisExp.addLoop(trial_istr_a_l2)  # add the loop to the experiment
        thisTrial_istr_a_l2 = trial_istr_a_l2.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_a_l2.rgb)
        if thisTrial_istr_a_l2 != None:
            for paramName in thisTrial_istr_a_l2:
                exec('{} = thisTrial_istr_a_l2[paramName]'.format(paramName))
        
        for thisTrial_istr_a_l2 in trial_istr_a_l2:
            currentLoop = trial_istr_a_l2
            # abbreviate parameter names if possible (e.g. rgb = thisTrial_istr_a_l2.rgb)
            if thisTrial_istr_a_l2 != None:
                for paramName in thisTrial_istr_a_l2:
                    exec('{} = thisTrial_istr_a_l2[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "istruzioni_a_l2" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_9.keys = []
            key_resp_9.rt = []
            _key_resp_9_allKeys = []
            # keep track of which components have finished
            istruzioni_a_l2Components = [text_13, key_resp_9]
            for thisComponent in istruzioni_a_l2Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "istruzioni_a_l2" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_13* updates
                if text_13.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_13.frameNStart = frameN  # exact frame index
                    text_13.tStart = t  # local t and not account for scr refresh
                    text_13.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_13, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_13.started')
                    text_13.setAutoDraw(True)
                
                # *key_resp_9* updates
                waitOnFlip = False
                if key_resp_9.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_9.frameNStart = frameN  # exact frame index
                    key_resp_9.tStart = t  # local t and not account for scr refresh
                    key_resp_9.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_9, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_9.started')
                    key_resp_9.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_9.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_9.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_9.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_9.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_9_allKeys.extend(theseKeys)
                    if len(_key_resp_9_allKeys):
                        key_resp_9.keys = _key_resp_9_allKeys[-1].name  # just the last key pressed
                        key_resp_9.rt = _key_resp_9_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in istruzioni_a_l2Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "istruzioni_a_l2" ---
            for thisComponent in istruzioni_a_l2Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_9.keys in ['', [], None]:  # No response was made
                key_resp_9.keys = None
            trial_istr_a_l2.addData('key_resp_9.keys',key_resp_9.keys)
            if key_resp_9.keys != None:  # we had a response
                trial_istr_a_l2.addData('key_resp_9.rt', key_resp_9.rt)
            # the Routine "istruzioni_a_l2" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed nIstrAL2 repeats of 'trial_istr_a_l2'
        
        
        # set up handler to look after randomisation of conditions etc
        prova_a = data.TrialHandler(nReps=1, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('ap'+expInfo['sex']+str(Cond_code)+'.xlsx'),
            seed=None, name='prova_a')
        thisExp.addLoop(prova_a)  # add the loop to the experiment
        thisProva_a = prova_a.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisProva_a.rgb)
        if thisProva_a != None:
            for paramName in thisProva_a:
                exec('{} = thisProva_a[paramName]'.format(paramName))
        
        for thisProva_a in prova_a:
            currentLoop = prova_a
            # abbreviate parameter names if possible (e.g. rgb = thisProva_a.rgb)
            if thisProva_a != None:
                for paramName in thisProva_a:
                    exec('{} = thisProva_a[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "trial" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            image.setImage(file_stim)
            label.setText(etichetta)
            risposta.keys = []
            risposta.rt = []
            _risposta_allKeys = []
            # keep track of which components have finished
            trialComponents = [fix, image, fix2, label, risposta]
            for thisComponent in trialComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "trial" ---
            while continueRoutine and routineTimer.getTime() < 1.6:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *fix* updates
                if fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fix.frameNStart = frameN  # exact frame index
                    fix.tStart = t  # local t and not account for scr refresh
                    fix.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fix, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix.started')
                    fix.setAutoDraw(True)
                if fix.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fix.tStartRefresh + 0.6-frameTolerance:
                        # keep track of stop time/frame for later
                        fix.tStop = t  # not accounting for scr refresh
                        fix.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fix.stopped')
                        fix.setAutoDraw(False)
                
                # *image* updates
                if image.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    image.frameNStart = frameN  # exact frame index
                    image.tStart = t  # local t and not account for scr refresh
                    image.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image.started')
                    image.setAutoDraw(True)
                if image.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image.tStartRefresh + 0.2-frameTolerance:
                        # keep track of stop time/frame for later
                        image.tStop = t  # not accounting for scr refresh
                        image.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image.stopped')
                        image.setAutoDraw(False)
                
                # *fix2* updates
                if fix2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fix2.frameNStart = frameN  # exact frame index
                    fix2.tStart = t  # local t and not account for scr refresh
                    fix2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fix2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix2.started')
                    fix2.setAutoDraw(True)
                if fix2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fix2.tStartRefresh + 0.6-frameTolerance:
                        # keep track of stop time/frame for later
                        fix2.tStop = t  # not accounting for scr refresh
                        fix2.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fix2.stopped')
                        fix2.setAutoDraw(False)
                
                # *label* updates
                if label.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    label.frameNStart = frameN  # exact frame index
                    label.tStart = t  # local t and not account for scr refresh
                    label.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(label, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'label.started')
                    label.setAutoDraw(True)
                if label.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > label.tStartRefresh + 0.2-frameTolerance:
                        # keep track of stop time/frame for later
                        label.tStop = t  # not accounting for scr refresh
                        label.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'label.stopped')
                        label.setAutoDraw(False)
                
                # *risposta* updates
                waitOnFlip = False
                if risposta.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    risposta.frameNStart = frameN  # exact frame index
                    risposta.tStart = t  # local t and not account for scr refresh
                    risposta.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(risposta, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'risposta.started')
                    risposta.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(risposta.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(risposta.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if risposta.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > risposta.tStartRefresh + 1.2-frameTolerance:
                        # keep track of stop time/frame for later
                        risposta.tStop = t  # not accounting for scr refresh
                        risposta.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'risposta.stopped')
                        risposta.status = FINISHED
                if risposta.status == STARTED and not waitOnFlip:
                    theseKeys = risposta.getKeys(keyList=['a','l'], waitRelease=False)
                    _risposta_allKeys.extend(theseKeys)
                    if len(_risposta_allKeys):
                        risposta.keys = _risposta_allKeys[-1].name  # just the last key pressed
                        risposta.rt = _risposta_allKeys[-1].rt
                        # was this correct?
                        if (risposta.keys == str(corretto)) or (risposta.keys == corretto):
                            risposta.corr = 1
                        else:
                            risposta.corr = 0
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in trialComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "trial" ---
            for thisComponent in trialComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if risposta.keys in ['', [], None]:  # No response was made
                risposta.keys = None
                # was no response the correct answer?!
                if str(corretto).lower() == 'none':
                   risposta.corr = 1;  # correct non-response
                else:
                   risposta.corr = 0;  # failed to respond (incorrectly)
            # store data for prova_a (TrialHandler)
            prova_a.addData('risposta.keys',risposta.keys)
            prova_a.addData('risposta.corr', risposta.corr)
            if risposta.keys != None:  # we had a response
                prova_a.addData('risposta.rt', risposta.rt)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.600000)
            
            # --- Prepare to start Routine "feedback" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            # Run 'Begin Routine' code from code
            if not risposta.keys:
                msg='!!!'
            elif risposta.corr == 1:
                msg='!!!'
            else:
                msg='OK'
            text_7.setText(msg)
            # keep track of which components have finished
            feedbackComponents = [text_7]
            for thisComponent in feedbackComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "feedback" ---
            while continueRoutine and routineTimer.getTime() < 0.5:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_7* updates
                if text_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_7.frameNStart = frameN  # exact frame index
                    text_7.tStart = t  # local t and not account for scr refresh
                    text_7.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_7, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_7.started')
                    text_7.setAutoDraw(True)
                if text_7.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > text_7.tStartRefresh + 0.5-frameTolerance:
                        # keep track of stop time/frame for later
                        text_7.tStop = t  # not accounting for scr refresh
                        text_7.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'text_7.stopped')
                        text_7.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "feedback" ---
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-0.500000)
            thisExp.nextEntry()
            
        # completed 1 repeats of 'prova_a'
        
        
        # --- Prepare to start Routine "inizio_blocco" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        key_resp_2.keys = []
        key_resp_2.rt = []
        _key_resp_2_allKeys = []
        # keep track of which components have finished
        inizio_bloccoComponents = [text_5, key_resp_2]
        for thisComponent in inizio_bloccoComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "inizio_blocco" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_5* updates
            if text_5.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_5.frameNStart = frameN  # exact frame index
                text_5.tStart = t  # local t and not account for scr refresh
                text_5.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_5, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_5.started')
                text_5.setAutoDraw(True)
            
            # *key_resp_2* updates
            waitOnFlip = False
            if key_resp_2.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                # keep track of start time/frame for later
                key_resp_2.frameNStart = frameN  # exact frame index
                key_resp_2.tStart = t  # local t and not account for scr refresh
                key_resp_2.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_2, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_2.started')
                key_resp_2.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_2.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_2.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_2.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_2.getKeys(keyList=['space'], waitRelease=False)
                _key_resp_2_allKeys.extend(theseKeys)
                if len(_key_resp_2_allKeys):
                    key_resp_2.keys = _key_resp_2_allKeys[-1].name  # just the last key pressed
                    key_resp_2.rt = _key_resp_2_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in inizio_bloccoComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "inizio_blocco" ---
        for thisComponent in inizio_bloccoComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if key_resp_2.keys in ['', [], None]:  # No response was made
            key_resp_2.keys = None
        trials_a.addData('key_resp_2.keys',key_resp_2.keys)
        if key_resp_2.keys != None:  # we had a response
            trials_a.addData('key_resp_2.rt', key_resp_2.rt)
        # the Routine "inizio_blocco" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        
        # set up handler to look after randomisation of conditions etc
        blocco_a = data.TrialHandler(nReps=1, method='random', 
            extraInfo=expInfo, originPath=-1,
            trialList=data.importConditions('a'+expInfo['sex']+str(Cond_code)+'.xlsx'),
            seed=None, name='blocco_a')
        thisExp.addLoop(blocco_a)  # add the loop to the experiment
        thisBlocco_a = blocco_a.trialList[0]  # so we can initialise stimuli with some values
        # abbreviate parameter names if possible (e.g. rgb = thisBlocco_a.rgb)
        if thisBlocco_a != None:
            for paramName in thisBlocco_a:
                exec('{} = thisBlocco_a[paramName]'.format(paramName))
        
        for thisBlocco_a in blocco_a:
            currentLoop = blocco_a
            # abbreviate parameter names if possible (e.g. rgb = thisBlocco_a.rgb)
            if thisBlocco_a != None:
                for paramName in thisBlocco_a:
                    exec('{} = thisBlocco_a[paramName]'.format(paramName))
            
            # --- Prepare to start Routine "trial" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            image.setImage(file_stim)
            label.setText(etichetta)
            risposta.keys = []
            risposta.rt = []
            _risposta_allKeys = []
            # keep track of which components have finished
            trialComponents = [fix, image, fix2, label, risposta]
            for thisComponent in trialComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "trial" ---
            while continueRoutine and routineTimer.getTime() < 1.6:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *fix* updates
                if fix.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fix.frameNStart = frameN  # exact frame index
                    fix.tStart = t  # local t and not account for scr refresh
                    fix.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fix, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix.started')
                    fix.setAutoDraw(True)
                if fix.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fix.tStartRefresh + 0.6-frameTolerance:
                        # keep track of stop time/frame for later
                        fix.tStop = t  # not accounting for scr refresh
                        fix.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fix.stopped')
                        fix.setAutoDraw(False)
                
                # *image* updates
                if image.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    image.frameNStart = frameN  # exact frame index
                    image.tStart = t  # local t and not account for scr refresh
                    image.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(image, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'image.started')
                    image.setAutoDraw(True)
                if image.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > image.tStartRefresh + 0.2-frameTolerance:
                        # keep track of stop time/frame for later
                        image.tStop = t  # not accounting for scr refresh
                        image.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'image.stopped')
                        image.setAutoDraw(False)
                
                # *fix2* updates
                if fix2.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    fix2.frameNStart = frameN  # exact frame index
                    fix2.tStart = t  # local t and not account for scr refresh
                    fix2.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(fix2, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'fix2.started')
                    fix2.setAutoDraw(True)
                if fix2.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > fix2.tStartRefresh + 0.6-frameTolerance:
                        # keep track of stop time/frame for later
                        fix2.tStop = t  # not accounting for scr refresh
                        fix2.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'fix2.stopped')
                        fix2.setAutoDraw(False)
                
                # *label* updates
                if label.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    label.frameNStart = frameN  # exact frame index
                    label.tStart = t  # local t and not account for scr refresh
                    label.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(label, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'label.started')
                    label.setAutoDraw(True)
                if label.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > label.tStartRefresh + 0.2-frameTolerance:
                        # keep track of stop time/frame for later
                        label.tStop = t  # not accounting for scr refresh
                        label.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'label.stopped')
                        label.setAutoDraw(False)
                
                # *risposta* updates
                waitOnFlip = False
                if risposta.status == NOT_STARTED and tThisFlip >= 0.4-frameTolerance:
                    # keep track of start time/frame for later
                    risposta.frameNStart = frameN  # exact frame index
                    risposta.tStart = t  # local t and not account for scr refresh
                    risposta.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(risposta, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'risposta.started')
                    risposta.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(risposta.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(risposta.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if risposta.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > risposta.tStartRefresh + 1.2-frameTolerance:
                        # keep track of stop time/frame for later
                        risposta.tStop = t  # not accounting for scr refresh
                        risposta.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'risposta.stopped')
                        risposta.status = FINISHED
                if risposta.status == STARTED and not waitOnFlip:
                    theseKeys = risposta.getKeys(keyList=['a','l'], waitRelease=False)
                    _risposta_allKeys.extend(theseKeys)
                    if len(_risposta_allKeys):
                        risposta.keys = _risposta_allKeys[-1].name  # just the last key pressed
                        risposta.rt = _risposta_allKeys[-1].rt
                        # was this correct?
                        if (risposta.keys == str(corretto)) or (risposta.keys == corretto):
                            risposta.corr = 1
                        else:
                            risposta.corr = 0
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in trialComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "trial" ---
            for thisComponent in trialComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if risposta.keys in ['', [], None]:  # No response was made
                risposta.keys = None
                # was no response the correct answer?!
                if str(corretto).lower() == 'none':
                   risposta.corr = 1;  # correct non-response
                else:
                   risposta.corr = 0;  # failed to respond (incorrectly)
            # store data for blocco_a (TrialHandler)
            blocco_a.addData('risposta.keys',risposta.keys)
            blocco_a.addData('risposta.corr', risposta.corr)
            if risposta.keys != None:  # we had a response
                blocco_a.addData('risposta.rt', risposta.rt)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-1.600000)
            
            # --- Prepare to start Routine "feedback" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            # Run 'Begin Routine' code from code
            if not risposta.keys:
                msg='!!!'
            elif risposta.corr == 1:
                msg='!!!'
            else:
                msg='OK'
            text_7.setText(msg)
            # keep track of which components have finished
            feedbackComponents = [text_7]
            for thisComponent in feedbackComponents:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "feedback" ---
            while continueRoutine and routineTimer.getTime() < 0.5:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_7* updates
                if text_7.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_7.frameNStart = frameN  # exact frame index
                    text_7.tStart = t  # local t and not account for scr refresh
                    text_7.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_7, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_7.started')
                    text_7.setAutoDraw(True)
                if text_7.status == STARTED:
                    # is it time to stop? (based on global clock, using actual start)
                    if tThisFlipGlobal > text_7.tStartRefresh + 0.5-frameTolerance:
                        # keep track of stop time/frame for later
                        text_7.tStop = t  # not accounting for scr refresh
                        text_7.frameNStop = frameN  # exact frame index
                        # add timestamp to datafile
                        thisExp.timestampOnFlip(win, 'text_7.stopped')
                        text_7.setAutoDraw(False)
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in feedbackComponents:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "feedback" ---
            for thisComponent in feedbackComponents:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
            if routineForceEnded:
                routineTimer.reset()
            else:
                routineTimer.addTime(-0.500000)
            
            # --- Prepare to start Routine "chiama_pausa_2" ---
            continueRoutine = True
            routineForceEnded = False
            # update component parameters for each repeat
            key_resp_7.keys = []
            key_resp_7.rt = []
            _key_resp_7_allKeys = []
            # Run 'Begin Routine' code from call_pause_2
            if blocco_a.thisN != 89:
                continueRoutine = False
            # keep track of which components have finished
            chiama_pausa_2Components = [text_11, key_resp_7]
            for thisComponent in chiama_pausa_2Components:
                thisComponent.tStart = None
                thisComponent.tStop = None
                thisComponent.tStartRefresh = None
                thisComponent.tStopRefresh = None
                if hasattr(thisComponent, 'status'):
                    thisComponent.status = NOT_STARTED
            # reset timers
            t = 0
            _timeToFirstFrame = win.getFutureFlipTime(clock="now")
            frameN = -1
            
            # --- Run Routine "chiama_pausa_2" ---
            while continueRoutine:
                # get current time
                t = routineTimer.getTime()
                tThisFlip = win.getFutureFlipTime(clock=routineTimer)
                tThisFlipGlobal = win.getFutureFlipTime(clock=None)
                frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
                # update/draw components on each frame
                
                # *text_11* updates
                if text_11.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                    # keep track of start time/frame for later
                    text_11.frameNStart = frameN  # exact frame index
                    text_11.tStart = t  # local t and not account for scr refresh
                    text_11.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(text_11, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'text_11.started')
                    text_11.setAutoDraw(True)
                
                # *key_resp_7* updates
                waitOnFlip = False
                if key_resp_7.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                    # keep track of start time/frame for later
                    key_resp_7.frameNStart = frameN  # exact frame index
                    key_resp_7.tStart = t  # local t and not account for scr refresh
                    key_resp_7.tStartRefresh = tThisFlipGlobal  # on global time
                    win.timeOnFlip(key_resp_7, 'tStartRefresh')  # time at next scr refresh
                    # add timestamp to datafile
                    thisExp.timestampOnFlip(win, 'key_resp_7.started')
                    key_resp_7.status = STARTED
                    # keyboard checking is just starting
                    waitOnFlip = True
                    win.callOnFlip(key_resp_7.clock.reset)  # t=0 on next screen flip
                    win.callOnFlip(key_resp_7.clearEvents, eventType='keyboard')  # clear events on next screen flip
                if key_resp_7.status == STARTED and not waitOnFlip:
                    theseKeys = key_resp_7.getKeys(keyList=['space'], waitRelease=False)
                    _key_resp_7_allKeys.extend(theseKeys)
                    if len(_key_resp_7_allKeys):
                        key_resp_7.keys = _key_resp_7_allKeys[-1].name  # just the last key pressed
                        key_resp_7.rt = _key_resp_7_allKeys[-1].rt
                        # a response ends the routine
                        continueRoutine = False
                
                # check for quit (typically the Esc key)
                if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                    core.quit()
                
                # check if all components have finished
                if not continueRoutine:  # a component has requested a forced-end of Routine
                    routineForceEnded = True
                    break
                continueRoutine = False  # will revert to True if at least one component still running
                for thisComponent in chiama_pausa_2Components:
                    if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                        continueRoutine = True
                        break  # at least one component has not yet finished
                
                # refresh the screen
                if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                    win.flip()
            
            # --- Ending Routine "chiama_pausa_2" ---
            for thisComponent in chiama_pausa_2Components:
                if hasattr(thisComponent, "setAutoDraw"):
                    thisComponent.setAutoDraw(False)
            # check responses
            if key_resp_7.keys in ['', [], None]:  # No response was made
                key_resp_7.keys = None
            blocco_a.addData('key_resp_7.keys',key_resp_7.keys)
            if key_resp_7.keys != None:  # we had a response
                blocco_a.addData('key_resp_7.rt', key_resp_7.rt)
            # the Routine "chiama_pausa_2" was not non-slip safe, so reset the non-slip timer
            routineTimer.reset()
            thisExp.nextEntry()
            
        # completed 1 repeats of 'blocco_a'
        
        thisExp.nextEntry()
        
    # completed nRepsTask2 repeats of 'trials_a'
    
    
    # set up handler to look after randomisation of conditions etc
    trial_fine_blocco = data.TrialHandler(nReps=nRepsTask3, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='trial_fine_blocco')
    thisExp.addLoop(trial_fine_blocco)  # add the loop to the experiment
    thisTrial_fine_blocco = trial_fine_blocco.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb = thisTrial_fine_blocco.rgb)
    if thisTrial_fine_blocco != None:
        for paramName in thisTrial_fine_blocco:
            exec('{} = thisTrial_fine_blocco[paramName]'.format(paramName))
    
    for thisTrial_fine_blocco in trial_fine_blocco:
        currentLoop = trial_fine_blocco
        # abbreviate parameter names if possible (e.g. rgb = thisTrial_fine_blocco.rgb)
        if thisTrial_fine_blocco != None:
            for paramName in thisTrial_fine_blocco:
                exec('{} = thisTrial_fine_blocco[paramName]'.format(paramName))
        
        # --- Prepare to start Routine "fine_primo_blocco" ---
        continueRoutine = True
        routineForceEnded = False
        # update component parameters for each repeat
        key_resp_4.keys = []
        key_resp_4.rt = []
        _key_resp_4_allKeys = []
        # keep track of which components have finished
        fine_primo_bloccoComponents = [text_8, key_resp_4]
        for thisComponent in fine_primo_bloccoComponents:
            thisComponent.tStart = None
            thisComponent.tStop = None
            thisComponent.tStartRefresh = None
            thisComponent.tStopRefresh = None
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        # reset timers
        t = 0
        _timeToFirstFrame = win.getFutureFlipTime(clock="now")
        frameN = -1
        
        # --- Run Routine "fine_primo_blocco" ---
        while continueRoutine:
            # get current time
            t = routineTimer.getTime()
            tThisFlip = win.getFutureFlipTime(clock=routineTimer)
            tThisFlipGlobal = win.getFutureFlipTime(clock=None)
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *text_8* updates
            if text_8.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
                # keep track of start time/frame for later
                text_8.frameNStart = frameN  # exact frame index
                text_8.tStart = t  # local t and not account for scr refresh
                text_8.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(text_8, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'text_8.started')
                text_8.setAutoDraw(True)
            
            # *key_resp_4* updates
            waitOnFlip = False
            if key_resp_4.status == NOT_STARTED and tThisFlip >= 3-frameTolerance:
                # keep track of start time/frame for later
                key_resp_4.frameNStart = frameN  # exact frame index
                key_resp_4.tStart = t  # local t and not account for scr refresh
                key_resp_4.tStartRefresh = tThisFlipGlobal  # on global time
                win.timeOnFlip(key_resp_4, 'tStartRefresh')  # time at next scr refresh
                # add timestamp to datafile
                thisExp.timestampOnFlip(win, 'key_resp_4.started')
                key_resp_4.status = STARTED
                # keyboard checking is just starting
                waitOnFlip = True
                win.callOnFlip(key_resp_4.clock.reset)  # t=0 on next screen flip
                win.callOnFlip(key_resp_4.clearEvents, eventType='keyboard')  # clear events on next screen flip
            if key_resp_4.status == STARTED and not waitOnFlip:
                theseKeys = key_resp_4.getKeys(keyList=['space'], waitRelease=False)
                _key_resp_4_allKeys.extend(theseKeys)
                if len(_key_resp_4_allKeys):
                    key_resp_4.keys = _key_resp_4_allKeys[-1].name  # just the last key pressed
                    key_resp_4.rt = _key_resp_4_allKeys[-1].rt
                    # a response ends the routine
                    continueRoutine = False
            
            # check for quit (typically the Esc key)
            if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
                core.quit()
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                routineForceEnded = True
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in fine_primo_bloccoComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        # --- Ending Routine "fine_primo_blocco" ---
        for thisComponent in fine_primo_bloccoComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if key_resp_4.keys in ['', [], None]:  # No response was made
            key_resp_4.keys = None
        trial_fine_blocco.addData('key_resp_4.keys',key_resp_4.keys)
        if key_resp_4.keys != None:  # we had a response
            trial_fine_blocco.addData('key_resp_4.rt', key_resp_4.rt)
        # the Routine "fine_primo_blocco" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
        thisExp.nextEntry()
        
    # completed nRepsTask3 repeats of 'trial_fine_blocco'
    
    thisExp.nextEntry()
    
# completed 1.0 repeats of 'controlTaskOrder'


# --- Prepare to start Routine "fine" ---
continueRoutine = True
routineForceEnded = False
# update component parameters for each repeat
# keep track of which components have finished
fineComponents = [end_exp]
for thisComponent in fineComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
frameN = -1

# --- Run Routine "fine" ---
while continueRoutine and routineTimer.getTime() < 3.0:
    # get current time
    t = routineTimer.getTime()
    tThisFlip = win.getFutureFlipTime(clock=routineTimer)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # *end_exp* updates
    if end_exp.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
        # keep track of start time/frame for later
        end_exp.frameNStart = frameN  # exact frame index
        end_exp.tStart = t  # local t and not account for scr refresh
        end_exp.tStartRefresh = tThisFlipGlobal  # on global time
        win.timeOnFlip(end_exp, 'tStartRefresh')  # time at next scr refresh
        # add timestamp to datafile
        thisExp.timestampOnFlip(win, 'end_exp.started')
        end_exp.setAutoDraw(True)
    if end_exp.status == STARTED:
        # is it time to stop? (based on global clock, using actual start)
        if tThisFlipGlobal > end_exp.tStartRefresh + 3-frameTolerance:
            # keep track of stop time/frame for later
            end_exp.tStop = t  # not accounting for scr refresh
            end_exp.frameNStop = frameN  # exact frame index
            # add timestamp to datafile
            thisExp.timestampOnFlip(win, 'end_exp.stopped')
            end_exp.setAutoDraw(False)
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        routineForceEnded = True
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in fineComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# --- Ending Routine "fine" ---
for thisComponent in fineComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# using non-slip timing so subtract the expected duration of this Routine (unless ended on request)
if routineForceEnded:
    routineTimer.reset()
else:
    routineTimer.addTime(-3.000000)

# --- End experiment ---
# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv', delim='auto')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
if eyetracker:
    eyetracker.setConnectionState(False)
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
