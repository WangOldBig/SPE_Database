### This script is used to preprocessing the data of the moral self experiment (DDM), experiment 2. 
#
### Hu, C-P., Lan, Y., Macrae, N., & Sui. J. (2019) 
### Script author: Chuan-Peng Hu
### Email = hcp4715@gmail.com       twitter= @hcp4715
#
### Input: 
###      MS_rep_matchTask_raw.csv -- raw data of matching task;
###      MS_rep_categTask_raw.csv -- raw data of categorization task;
#
### Output:
###     df.M.hddm_m_stim.csv.csv  -- clean data of matching trials from matchign task, for HDDM analysis;
###     df.M.hddm_nm_stim.csv.csv -- clean data of nonmatching trials from matchign task, for HDDM analysis;
###     df.C.hddm_val_stim.csv    -- clean data of valence-based categorization trials, for HDDM analysis;
###     df.C.hddm_id_stim.csv     -- clean data of identity-based categorization trials, for HDDM analysis;
# 
###     MS_categ_behav_wide.csv        -- cleaned summary results (wide-format) of categorization task for 
###                                             statistical analysis in JASP
###     MS_categ_behav_noTask_wide.csv -- cleaned summary results (wide-format) of categorization task (collapsed
###                                             data from different task) for statistical analysis in JASP
###     MS_categ__rt_acc_long.csv      -- cleaned summary results of RT and accuracy (long-format) of 
###                                             categorization task, for JASP analysis
###     MS_categ__rt_acc_noTask_long.csv -- cleaned summary reuslt of RT and accuracy (long-format) of categorization 
###                                             task (collapsed data from different task) for JASP analysis
###     MS_cross_taskeffect_wide.csv    -- cleaned summary results for cross task analysis

# ---------- Table of Contents ----------------------------------------------------------
# ---------- 1. Initializing and prepare ------------------------------------------------
# ---------- 2. Loading data and clean the data -----------------------------------------
# ---------- 3. Matching task: prepare the Accuracy, d-prime and RT ---------------------
# ---------- 4. Categorization task: prepare the Accuracy and RT ------------------------
# ---------- 5. Plots -------------------------------------------------------------------


# ---------------------------------------------------------------------------------------
# ---------- 1. Initializing and prepare               ----------------------------------
# ---------------------------------------------------------------------------------------

curDir  <- dirname(rstudioapi::getSourceEditorContext()$path)   # get the directory for preprocessing
setwd(curDir)
source('Initial_ms_rep.r')  # initializing (clear global environment; load packages and functions)
curDir  <- dirname(rstudioapi::getSourceEditorContext()$path)   # get the directory for preprocessing
rootDir <- gsub('.{9}$', '', curDir)                            # get the parental folder
traDir  <- paste(rootDir,'2_trad_analysis',sep = '')        # folder for traditional analsysi
ddmDir  <- paste(rootDir,'3_hddm',sep = '')                        # folder for DDM analysis

# ---------------------------------------------------------------------------------------
# ---------- 2. Loading data and clean the data        ----------------------------------
# ---------------------------------------------------------------------------------------

df.M <- read.csv('MS_rep_matchingTask_raw.csv', header=TRUE, sep=",",stringsAsFactors=F)
df.C <- read.csv('MS_rep_categTask_raw.csv', header=TRUE, sep=",",stringsAsFactors=F)

###############################
###  Excluding particpants ####
###############################

### Rule 1: wrong trials numbers because of procedure errors
excldSub1_M <- df.M %>%
   dplyr::mutate(ACC = ifelse(ACC == 1, 1, 0))  %>%  # no response as wrong
   dplyr::group_by(Subject, Match, Identity,Morality) %>%
   dplyr::summarise(N = length(ACC)) %>%  # count the trial # for each condition of each subject
   dplyr::ungroup() %>%
   dplyr::filter(N != 75) %>%             # filter the rows that trial Number is not 75
   dplyr::distinct(Subject) %>%           # find the unique subject ID
   dplyr::pull(Subject)                   # pull the subj ID as vector


excldSub1_C <- df.C %>%
   dplyr::mutate(ACC = ifelse(ACC == 1, 1, 0))  %>%  # no response as wrong
   dplyr::group_by(Subject, Task, Identity,Morality) %>%
   dplyr::summarise(N = length(ACC)) %>%  # count the trial # for each condition of each subject
   dplyr::ungroup() %>%
   dplyr::filter(N != 90) %>%             # filter the rows that trial Number is not 90
   dplyr::distinct(Subject) %>%           # find the unique subject ID
   dplyr::pull(Subject)                   # pull the subj ID as vector


### Rule 2:  overall accuracy < 0.5
excldSub2_M <- df.M %>%
   dplyr::mutate(ACC = ifelse(ACC == 1, 1, 0))  %>%  # no response as wrong
   dplyr::group_by(Subject) %>%
   dplyr::summarise(N = length(ACC),
                    countN = sum(ACC),
                    ACC = sum(ACC)/length(ACC)) %>%  # count the trial # for each condition of each subject
   dplyr::ungroup() %>%
   dplyr::filter(ACC < .5) %>%             # filter the subjects with over all ACC < 0.5
   dplyr::distinct(Subject) %>%             # find the unique subject ID
   dplyr::pull(Subject)                     # pull the subj ID as vector

excldSub2_C <- df.C %>%
   dplyr::mutate(ACC = ifelse(ACC == 1, 1, 0))  %>%  # no response as wrong
   dplyr::group_by(Subject) %>%
   dplyr::summarise(N = length(ACC),
                    countN = sum(ACC),
                    ACC = sum(ACC)/length(ACC)) %>%  # count the trial # for each condition of each subject
   dplyr::ungroup() %>%
   dplyr::filter(ACC < .5) %>%             # filter the subjects with over all ACC < 0.5
   dplyr::distinct(Subject) %>%             # find the unique subject ID
   dplyr::pull(Subject)                     # pull the subj ID as vector

### Rule 3:  one condition with zero ACC
excldSub3_M <- df.M %>%
   dplyr::mutate(ACC = ifelse(ACC == 1, 1, 0))  %>%  # no response as wrong
   dplyr::group_by(Subject, Match, Identity,Morality) %>%
   dplyr::summarise(N = length(ACC),
                    countN = sum(ACC),
                    ACC = sum(ACC)/length(ACC)) %>%  # count the trial # for each condition of each subject
   dplyr::ungroup() %>%
   dplyr::filter(ACC == 0) %>%             # filter the subjects with over all ACC < 0.5
   dplyr::distinct(Subject) %>%             # find the unique subject ID
   dplyr::pull(Subject)                     # pull the subj ID as vector

excldSub3_C <- df.C %>%
   dplyr::mutate(ACC = ifelse(ACC == 1, 1, 0))  %>%  # no response as wrong
   dplyr::group_by(Subject, Task, Identity,Morality) %>%
   dplyr::summarise(N = length(ACC),
                    countN = sum(ACC),
                    ACC = sum(ACC)/length(ACC)) %>%  # count the trial # for each condition of each subject
   dplyr::ungroup() %>%
   dplyr::filter(ACC == 0) %>%             # filter the subjects with over all ACC < 0.5
   dplyr::distinct(Subject) %>%             # find the unique subject ID
   dplyr::pull(Subject)                     # pull the subj ID as vector
   

# all participants excluded
excldSub_M   <- c(excldSub1_M, excldSub2_M,excldSub3_M) # 7302, 7303
excldSub_C   <- c(excldSub1_C, excldSub2_C,excldSub3_C) # 7302, 7303, 7338

# select valid data for further analysis
df.M1.V <- df.M %>%
   dplyr::mutate(ACC = ifelse(ACC == 1, 1, 0))  %>%  # no response as wrong
   dplyr::filter(Subject,!Subject %in% excldSub_M)   # exclude the invalid subjects

df.C1.V <- df.C %>%
   dplyr::mutate(ACC = ifelse(ACC == 1, 1, 0))  %>%  # no response as wrong
   dplyr::filter(Subject,!Subject %in% excldSub_C)   # exclude the invalid subjects

# check the number of participants are correct
length(unique(df.M1.V$Subject)) + length(excldSub_M) == length(unique(df.M$Subject))
length(unique(df.C1.V$Subject)) + length(excldSub_C) == length(unique(df.C$Subject))


# excluded correct trials with < 200ms RT
ratio.excld.trials.M <- nrow(df.M1.V[df.M1.V$RT*1000 <= 200 & df.M1.V$ACC == 1,])/nrow(df.M1.V)  # ratio of invalid trials
ratio.excld.trials.C <- nrow(df.C1.V[df.C1.V$RT*1000 <= 200 & df.C1.V$ACC == 1,])/nrow(df.C1.V)

df.M1.V <- df.M1.V %>% dplyr::filter(!(RT <= 0.2 & ACC==1)) # filter invalid trials
df.C1.V <- df.C1.V %>% dplyr::filter(!(RT <= 0.2 & ACC==1)) # filter invalid trials

## Basic information of the data ####
df.M1.T.basic <- df.M %>%
   dplyr::select(Subject, Age, Sex) %>%
   dplyr::distinct(Subject, Age, Sex) %>%
   dplyr::summarise(subj_N = length(Subject),
                    female_N = sum(Sex == 'female'),
                    male_N = sum(Sex == 'male'),
                    Age_mean = round(mean(Age),2),
                    Age_sd   = round(sd(Age),2))

# valide data for matching task
df.M1.V.basic <- df.M1.V %>%
   dplyr::select(Subject, Age, Sex) %>%
   dplyr::distinct(Subject, Age, Sex) %>%
   dplyr::summarise(subj_N = length(Subject),
                    female_N = sum(Sex == 'female'),
                    male_N = sum(Sex == 'male'),
                    Age_mean = round(mean(Age),2),
                    Age_sd   = round(sd(Age),2))

# valid data for categorization task
df.C1.V.basic <- df.C1.V %>%
   dplyr::select(Subject, Age, Sex) %>%
   dplyr::distinct(Subject, Age, Sex) %>%
   dplyr::summarise(subj_N = length(Subject),
                    female_N = sum(Sex == 'female'),
                    male_N = sum(Sex == 'male'),
                    Age_mean = round(mean(Age),2),
                    Age_sd   = round(sd(Age),2))

###########################################################
########   prep the data file for hddm analysis     #######
###########################################################
# exclusion trials, criterion: trials without response or wrong key
# Note: we didn't remove the correct response less than 200 ms
##################################################
### preparing the data for Stimuli-code hddm  ####
##################################################

df.M.hddm_m <- df.M %>%                                 # start from the valid data, RT in seconds.
   dplyr::filter(Subject,!Subject %in% excldSub_M) %>%
   dplyr::filter(ACC == 1 | ACC == 0) %>%               # exclude trials without response or with wrong keys
   dplyr::filter(Match == 'match') %>%
   dplyr::select(Subject,Match, Morality,Identity,RT,ACC) %>%  # select column
   dplyr::rename(subj_idx = Subject, match = Match, val = Morality, id = Identity, rt = RT, response = ACC) # rename column

df.M.hddm_nm <- df.M %>%
   dplyr::filter(Subject,!Subject %in% excldSub_M) %>%
   dplyr::filter(ACC == 1 | ACC == 0) %>%               # exclude trials without response or with wrong keys
   dplyr::filter(Match == 'mismatch') %>%
   dplyr::select(Subject,Morality,Identity,RT,ACC) %>%  # select column
   dplyr::rename(subj_idx = Subject, val = Morality, id = Identity, rt = RT, response = ACC) # rename column

df.M.hddm_stim <- df.M %>%
   dplyr::filter(Subject,!Subject %in% excldSub_M) %>%
   dplyr::filter(ACC == 1 | ACC == 0) %>%               # exclude trials without response or with wrong keys
   dplyr::mutate(response = ifelse((Match == "match" & ACC ==1) | (Match == "mismatch" & ACC ==0), 1, 0)) %>%
   dplyr::mutate(stim = ifelse(Match == "match", 1, 0)) %>%
   dplyr::select(Subject,Match,Morality,Identity,stim,response,RT) %>%  # select column
   dplyr::rename(subj_idx = Subject, match = Match, val = Morality, id = Identity, rt = RT) # rename column


##################################################
### preparing the data for Stimuli-code hddm  ####
##################################################
# for valence based, stim: moral = 1, immoral = 0; response: moralKey = 1; immoralKey = 0
df.C.hddm_val_stim <- df.C %>%
   dplyr::filter(Subject,!Subject %in% excldSub_C) %>%
   dplyr::filter(ACC == 1 | ACC == 0) %>%               # exclude trials without response or with wrong keys
   dplyr::filter(Task == 'Val') %>%                     # select the valence-based task
   dplyr::mutate(response = ifelse((Morality == "Good" & ACC ==1) | (Morality == "Bad" & ACC ==0), 1, 0)) %>%
   dplyr::select(Subject,Morality,Identity,Shape, response, RT) %>%  # select column
   dplyr::rename(subj_idx = Subject, val = Morality, id = Identity, rt = RT, stim = Shape) %>% # rename column
   dplyr::mutate(stim = ifelse(stim == "moralSelf" | stim == "moralOther" ,1, 0))

# for Id based, stim: self = 1, other = 0; response: selfKey = 1; otherKey = 0
df.C.hddm_id_stim <- df.C%>%
   dplyr::filter(Subject,!Subject %in% excldSub_C) %>%
   dplyr::filter(ACC == 1 | ACC == 0) %>%               # exclude trials without response or with wrong keys
   dplyr::filter(Task == 'Id') %>%                      # select the valence-based task
   dplyr::mutate(response = ifelse((Identity =="Self" & ACC==1) | (Identity =="Other" & ACC==0), 1, 0)) %>%
   dplyr::select(Subject,Morality,Identity,Shape, response, RT) %>%  # select column
   dplyr::rename(subj_idx = Subject, val = Morality, id = Identity, rt = RT, stim = Shape) %>% # rename column
   dplyr::mutate(stim = ifelse(stim == "moralSelf" | stim == "immoralSelf",1, 0))

setwd(ddmDir)
write.csv(df.M.hddm_m,'MS_match_hddm.csv',row.names = F)
write.csv(df.M.hddm_nm,'MS_mismatch_hddm.csv',row.names = F)
write.csv(df.M.hddm_stim,'MS_match_hddm_stim.csv',row.names = F)
write.csv(df.C.hddm_val_stim,'MS_categ_val_hddm_stim.csv',row.names = F)
write.csv(df.C.hddm_id_stim,'MS_categ_id_hddm_stim.csv',row.names = F)
setwd(curDir)
rm('df.M.hddm_m','df.M.hddm_nm','df.M.hddm_stim','df.C.hddm_val_stim','df.C.hddm_id_stim')


# ---------------------------------------------------------------------------------------
# -------- 3. Matching task: prepare the Accuracy, d-prime and RT -----------------------
# ---------------------------------------------------------------------------------------

####################################
###############   ACC    ###########
####################################
df.M1.V.acc  <- df.M1.V %>%
      dplyr::group_by(Subject, Match, Morality, Identity)  %>% 
      dplyr::summarise(N = length(ACC),
                       countN = sum(ACC),
                       ACC = sum(ACC)/length(ACC))

# transform to wide-format
df.M1.V.acc_w <- reshape2::dcast(df.M1.V.acc, Subject ~ Match + Morality + Identity,value.var = "ACC")

# rename the column number
colnames(df.M1.V.acc_w)[2:9] <- paste("ACC", colnames(df.M1.V.acc_w[,2:9]), sep = "_")

####################################
############   d prime   ###########
####################################
# calculate the number of hit,CR,miss or FA 
df.M1.V$sdt <- NA
for (i in 1:nrow(df.M1.V)){
      if (df.M1.V$ACC[i] == 1 & df.M1.V$Match[i] == "match"){
            df.M1.V$sdt[i] <- "hit"
      } else if (df.M1.V$ACC[i] == 1 & df.M1.V$Match[i] == "mismatch" ){
            df.M1.V$sdt[i] <- "CR"
      } else if (df.M1.V$ACC[i] == 0 & df.M1.V$Match[i] == "match"){
            df.M1.V$sdt[i] <- "miss"
      } else if (df.M1.V$ACC[i] == 0 & df.M1.V$Match[i] == "mismatch" ){
            df.M1.V$sdt[i] <- "FA"
      }
}

# calculate the number of each for each condition
df.M1.V.SDT <- df.M1.V %>%
   dplyr::group_by(Subject,Age, Sex, Morality, Identity,sdt) %>%
   dplyr::summarise(N = length(sdt)) %>%
   dplyr::filter(!is.na(sdt))           # no NAs

# long format to wide
df.M1.V.SDT_w <- reshape2::dcast(df.M1.V.SDT, Subject + Age + Sex + Morality + Identity ~ sdt,value.var = "N")
df.M1.V.SDT_w <- df.M1.V.SDT_w %>%
   dplyr::mutate(miss = ifelse(is.na(miss),0,miss), # if not miss trial, to 0
                 FA   = ifelse(is.na(FA),0,FA),     # if not FA trial, to 0
                 hitR = hit/(hit + miss),           # calculate the hit rate
                 faR  = FA/(FA+CR))                 # calculate the FA rate


# standardized way to deal with the extreme values
for (i in 1:nrow(df.M1.V.SDT_w)){
      if (df.M1.V.SDT_w$hitR[i] == 1){
            df.M1.V.SDT_w$hitR[i] <- 1 - 1/(2*(df.M1.V.SDT_w$hit[i] + df.M1.V.SDT_w$miss[i]))
      }
}

for (i in 1:nrow(df.M1.V.SDT_w)){
      if (df.M1.V.SDT_w$faR[i] == 0){
            df.M1.V.SDT_w$faR[i] <- 1/(2*(df.M1.V.SDT_w$FA[i] + df.M1.V.SDT_w$CR[i]))
      }
}

# calculate the d prime for each condition
df.M1.V.SDT_w$dprime <- mapply(dprime,df.M1.V.SDT_w$hitR,df.M1.V.SDT_w$faR)

# transfor from long format to wide format
df.M1.V.SDT_ww <- reshape2::dcast(df.M1.V.SDT_w, Subject + Age + Sex ~ Morality + Identity ,value.var = "dprime")
# rename the column number
colnames(df.M1.V.SDT_ww)[4:7] <- paste("d", colnames(df.M1.V.SDT_ww[,4:7]), sep = "_")

df.M1.V.SDT_l <- df.M1.V.SDT_w[,c(1:5,12)]

####################################
############      RT     ###########
####################################

df.M1.V.RT <- df.M1.V[df.M1.V$ACC == 1,]

# get the summary results
df.M1.V.RT.subj <- summarySEwithin(df.M1.V.RT,measurevar = 'RT', withinvar = c('Subject','Match','Morality','Identity'),idvar = 'Subject', na.rm = TRUE)
df.M1.V.RT.subj_w <- reshape2::dcast(df.M1.V.RT.subj, Subject ~ Match + Morality + Identity ,value.var = "RT") 

# rename the columns of RT data
colnames(df.M1.V.RT.subj_w)[2:9] <- paste("RT", colnames(df.M1.V.RT.subj_w[,2:9]), sep = "_")

## saving data ####
# merge the dprime and RT data and save (wide-format)
df.M1.V.sum_w <- merge(df.M1.V.acc_w,  df.M1.V.SDT_ww,by = "Subject")
df.M1.V.sum_w <- merge(df.M1.V.sum_w,df.M1.V.RT.subj_w,by = 'Subject')

# merge the RT and ACC data (long-format)
df.M1.V.sum_rt_acc_l <- merge(df.M1.V.acc,df.M1.V.RT.subj,by = c("Subject","Match","Morality",'Identity'))
df.M1.V.sum_rt_acc_l <- df.M1.V.sum_rt_acc_l[order(df.M1.V.sum_rt_acc_l$Subject),]

df.M1.V.sum_rt_acc_l <- df.M1.V.sum_rt_acc_l[,c("Subject","Match","Morality",'Identity',"N.x","countN","ACC","RT")]
colnames(df.M1.V.sum_rt_acc_l) <- c("Subject","Match","Morality",'Identity',"Ntrials","corrTrials","ACC","RT")

# order the columns
df.M1.V.sum_w <- df.M1.V.sum_w[,c(colnames(df.M1.V.sum_w)[c(1,10:11,2:9,12:23)])]


####################################
#####  effects in matching  ########
####################################
# calculate the effect of self-ref and valence
df.M1.v.sum_eff_w <- df.M1.V.sum_w[,1:3]
df.M1.v.sum_eff_w$d_goodslf_goodoth <- df.M1.V.sum_w$d_Good_Self - df.M1.V.sum_w$d_Good_Other
df.M1.v.sum_eff_w$d_goodslf_badslf  <- df.M1.V.sum_w$d_Good_Self - df.M1.V.sum_w$d_Bad_Self
df.M1.v.sum_eff_w$d_goodoth_badoth  <- df.M1.V.sum_w$d_Good_Other - df.M1.V.sum_w$d_Bad_Other
df.M1.v.sum_eff_w$d_badslf_badoth   <- df.M1.V.sum_w$d_Bad_Self - df.M1.V.sum_w$d_Bad_Other

df.M1.v.sum_eff_w$RT_goodslf_goodoth <- df.M1.V.sum_w$RT_match_Good_Other -  df.M1.V.sum_w$RT_match_Good_Self
df.M1.v.sum_eff_w$RT_goodslf_badslf  <- df.M1.V.sum_w$RT_match_Bad_Self -  df.M1.V.sum_w$RT_match_Good_Self
df.M1.v.sum_eff_w$RT_goodoth_badoth  <- df.M1.V.sum_w$RT_match_Bad_Other -  df.M1.V.sum_w$RT_match_Good_Other
df.M1.v.sum_eff_w$RT_badslf_badoth   <- df.M1.V.sum_w$RT_match_Bad_Self -  df.M1.V.sum_w$RT_match_Bad_Other

# write files
setwd(traDir)
write.csv(df.M1.V.sum_w,'MS_match_behav_wide.csv',row.names = F)
write.csv(df.M1.V.SDT_l,'MS_match__dprime_long.csv',row.names = F)
write.csv(df.M1.V.sum_rt_acc_l,'MS_match__rt_acc_long.csv',row.names = F)
setwd(curDir)


# ---------------------------------------------------------------------------------------
# ---------- 4. Categorization task: prepare the Accuracy and RT ------------------------
# ---------------------------------------------------------------------------------------

####################################
###############   ACC    ###########
####################################

df.C1.V.acc <- plyr::ddply(df.C1.V,.(Subject,Age, Sex, Task,Morality,Identity), summarise,
                           N = length(ACC),
                           countN = sum(ACC),
                           ACC = sum(ACC)/length(ACC))

# wide-format
df.C1.V.acc_w  <- reshape2::dcast(df.C1.V.acc, Subject ~ Task + Morality + Identity ,value.var = "ACC")
# rename the column number
colnames(df.C1.V.acc_w)[2:9] <- paste("ACC", colnames(df.C1.V.acc_w[,2:9]), sep = "_")

# combing data from diff task for analyzing the interaction btw val and id
df.C1.V.acc_noTask  <-  plyr::ddply(df.C1.V,.(Subject, Morality, Identity), summarise,
                                    N = length(ACC),
                                    countN = sum(ACC),
                                    ACC = sum(ACC)/length(ACC))

df.C1.V.acc_noTask_w <- reshape2::dcast(df.C1.V.acc_noTask, Subject ~ Morality + Identity,value.var = "ACC")
# rename the column number
colnames(df.C1.V.acc_noTask_w)[2:5] <- paste("ACC", colnames(df.C1.V.acc_noTask_w[,2:5]), sep = "_")

# calculate the mean differences(?)
df.C1.V.acc_noTask_w$good_bad_slf <- df.C1.V.acc_noTask_w$ACC_Good_Self - df.C1.V.acc_noTask_w$ACC_Bad_Self
df.C1.V.acc_noTask_w$good_bad_oth <- df.C1.V.acc_noTask_w$ACC_Good_Self - df.C1.V.acc_noTask_w$ACC_Bad_Other
df.C1.V.acc_noTask_w$slf_oth_good <- df.C1.V.acc_noTask_w$ACC_Good_Self - df.C1.V.acc_noTask_w$ACC_Good_Other
df.C1.V.acc_noTask_w$slf_oth_bad  <- df.C1.V.acc_noTask_w$ACC_Bad_Self - df.C1.V.acc_noTask_w$ACC_Bad_Other

####################################
###############   RT     ###########
####################################

df.C1.V.RT <- df.C1.V[df.C1.V$ACC == 1,]  # exclued inaccurate data
df.C1.V.RT.subj <- summarySEwithin(df.C1.V.RT,measurevar = 'RT', withinvar = c('Subject','Task','Morality','Identity'), idvar = 'Subject',na.rm = TRUE)
df.C1.V.RT.subj_w <- reshape2::dcast(df.C1.V.RT.subj, Subject ~ Task + Morality + Identity ,value.var = "RT") 

# rename the columns of RT data
colnames(df.C1.V.RT.subj_w)[2:9] <- paste("RT", colnames(df.C1.V.RT.subj_w[,2:9]), sep = "_")

# combining data form different task for analyszing interaction of val and id
df.C1.V.RT.subj_noTask <- summarySEwithin(df.C1.V.RT,measurevar = 'RT', withinvar = c('Subject','Morality','Identity'), idvar = 'Subject',na.rm = TRUE)
df.C1.V.RT.subj_noTask_w <- reshape2::dcast(df.C1.V.RT.subj_noTask, Subject ~ Morality + Identity ,value.var = "RT") 

# rename the columns of RT data
colnames(df.C1.V.RT.subj_noTask_w)[2:5] <- paste("RT", colnames(df.C1.V.RT.subj_noTask_w[,2:5]), sep = "_")

## saving data ####
# merge the accuracy and RT data and save
df.C1.V.sum_w <- merge(df.C1.V.acc_w,  df.C1.V.RT.subj_w,by = "Subject")
df.C1.V.sum_noTask_w <- merge(df.C1.V.acc_noTask_w,  df.C1.V.RT.subj_noTask_w,by = "Subject")

####################################
## effects in categorization  ######
####################################
# calculate the effect of self-ref and valence
df.C1.v.sum_eff_w <- data.frame(df.C1.V.sum_w[,c('Subject')])
colnames(df.C1.v.sum_eff_w) <- 'Subject'
df.C1.v.sum_eff_w$Val_RT_goodslf_goodoth <- df.C1.V.sum_w$RT_Val_Good_Other - df.C1.V.sum_w$RT_Val_Good_Self
df.C1.v.sum_eff_w$Val_RT_goodslf_badslf  <- df.C1.V.sum_w$RT_Val_Bad_Self - df.C1.V.sum_w$RT_Val_Good_Self
df.C1.v.sum_eff_w$Val_RT_goodoth_badoth  <- df.C1.V.sum_w$RT_Val_Bad_Other - df.C1.V.sum_w$RT_Val_Good_Other
df.C1.v.sum_eff_w$Val_RT_badslf_badoth   <- df.C1.V.sum_w$RT_Val_Bad_Self - df.C1.V.sum_w$RT_Val_Bad_Other

df.C1.v.sum_eff_w$Id_RT_goodslf_goodoth  <- df.C1.V.sum_w$RT_Id_Good_Other - df.C1.V.sum_w$RT_Id_Good_Self
df.C1.v.sum_eff_w$Id_RT_goodslf_badslf   <- df.C1.V.sum_w$RT_Id_Bad_Self - df.C1.V.sum_w$RT_Id_Good_Self
df.C1.v.sum_eff_w$Id_RT_goodoth_badoth   <- df.C1.V.sum_w$RT_Id_Bad_Other - df.C1.V.sum_w$RT_Id_Good_Other
df.C1.v.sum_eff_w$Id_RT_badslf_badoth    <- df.C1.V.sum_w$RT_Id_Bad_Self - df.C1.V.sum_w$RT_Id_Bad_Other

df.C1.v.sum_eff_w$Val_ACC_goodslf_goodoth <- df.C1.V.sum_w$ACC_Val_Good_Self - df.C1.V.sum_w$ACC_Val_Good_Other
df.C1.v.sum_eff_w$Val_ACC_goodslf_badslf  <- df.C1.V.sum_w$ACC_Val_Good_Self - df.C1.V.sum_w$ACC_Val_Bad_Self
df.C1.v.sum_eff_w$Val_ACC_goodoth_badoth  <- df.C1.V.sum_w$ACC_Val_Good_Other - df.C1.V.sum_w$ACC_Val_Bad_Other
df.C1.v.sum_eff_w$Val_ACC_badslf_badoth   <- df.C1.V.sum_w$ACC_Val_Bad_Self - df.C1.V.sum_w$ACC_Val_Bad_Other

df.C1.v.sum_eff_w$Id_ACC_goodslf_goodoth  <- df.C1.V.sum_w$ACC_Id_Good_Self - df.C1.V.sum_w$ACC_Id_Good_Other
df.C1.v.sum_eff_w$Id_ACC_goodslf_badslf   <- df.C1.V.sum_w$ACC_Id_Good_Self - df.C1.V.sum_w$ACC_Id_Bad_Self
df.C1.v.sum_eff_w$Id_ACC_goodoth_badoth   <- df.C1.V.sum_w$ACC_Id_Good_Other - df.C1.V.sum_w$ACC_Id_Bad_Other
df.C1.v.sum_eff_w$Id_ACC_badslf_badoth    <- df.C1.V.sum_w$ACC_Id_Bad_Self - df.C1.V.sum_w$ACC_Id_Bad_Other

# merge the effect file
df.v.sum_eff_all_w <- merge(df.M1.v.sum_eff_w,df.C1.v.sum_eff_w,by="Subject")

# merge the RT and ACC data (long-format) ####
df.C1.V.sum_rt_acc_l <- merge(df.C1.V.acc,df.C1.V.RT.subj,by = c("Subject","Task","Morality",'Identity'))
df.C1.V.sum_rt_acc_l <- df.C1.V.sum_rt_acc_l[order(df.C1.V.sum_rt_acc_l$Subject),]

df.C1.V.sum_rt_acc_l <- df.C1.V.sum_rt_acc_l[,c("Subject","Task","Morality",'Identity',"N.x","countN","ACC","RT")]
colnames(df.C1.V.sum_rt_acc_l) <- c("Subject","Task","Morality",'Identity',"Ntrials","corrTrials","ACC","RT")

# merge the RT and ACC data without task (long-format) ####
df.C1.V.sum_rt_acc_noTask_l <- merge(df.C1.V.acc_noTask,df.C1.V.RT.subj_noTask,by = c("Subject","Morality",'Identity'))
df.C1.V.sum_rt_acc_noTask_l <- df.C1.V.sum_rt_acc_noTask_l[order(df.C1.V.sum_rt_acc_noTask_l$Subject),]

df.C1.V.sum_rt_acc_noTask_l <- df.C1.V.sum_rt_acc_noTask_l[,c("Subject","Morality",'Identity',"N.x","countN","ACC","RT")]
colnames(df.C1.V.sum_rt_acc_noTask_l) <- c("Subject","Morality",'Identity',"Ntrials","corrTrials","ACC","RT")

# write files to an upper-level folder
setwd(traDir)
write.csv(df.C1.V.sum_w,'MS_categ_behav_wide.csv',row.names = F)
write.csv(df.C1.V.sum_noTask_w,'MS_categ_behav_noTask_wide.csv',row.names = F)
#write.csv(df.C1.V.sum_rt_acc_l,'MS_categ__rt_acc_long.csv',row.names = F)
#write.csv(df.C1.V.sum_rt_acc_noTask_l,'MS_categ__rt_acc_noTask_long.csv',row.names = F)
write.csv(df.v.sum_eff_all_w,'MS_cross_taskeffect_wide.csv',row.names = F)
setwd(curDir)


# ---------------------------------------------------------------------------------------
# ------------ 5. Plots  ----------------------------------------------------------------
# ---------------------------------------------------------------------------------------
# plot for match
df.M1.plot <- df.M1.V.sum_rt_acc_l %>%
   dplyr::mutate(RT = RT*1000) %>%
   dplyr::filter(Match == 'match') %>%  # select matching data for plotting only.
   dplyr::full_join(., df.M1.V.SDT_l) %>%  
   tidyr::pivot_longer(., cols = c(RT, dprime), 
                       names_to = 'DVs', 
                       values_to = "value") %>% # to longer format
   dplyr::mutate(Identity = factor(Identity, levels = c('Self','Other')),
                 DVs = factor(DVs, levels = c('RT', 'dprime')),
                 # create an extra column for ploting the individual data cross different conditions.
                 Conds = mosaic::derivedFactor("0.88" = (Identity == "Self" & Morality == 'Good'), 
                                               "1.12" = (Identity == "Other" & Morality == 'Good'), 
                                               "1.88" = (Identity == "Self" & Morality == 'Bad'),
                                               "2.12" = (Identity == "Other" & Morality == 'Bad'), 
                                               method ="first", .default = NA),
                 Conds = as.numeric(as.character(Conds)))


df.M1.sum_p <- summarySE(df.M1.plot, measurevar = "value", groupvars = c("Identity", 'Morality',"DVs")) %>%
   dplyr::mutate(Mrl_num = ifelse(Morality == 'Good', 1, 2))

pd1 <- position_dodge(0.5)
scaleFUN <- function(x) sprintf("%.2f", x)
scales_y <- list(
   RT = scale_y_continuous(limits = c(400, 900)),
   dprime = scale_y_continuous(labels=scaleFUN)
)

# New facet label names for panel variable
# https://stackoverflow.com/questions/34040376/cannot-italicize-facet-labels-with-labeller-label-parsed
levels(df.M1.plot$DVs ) <- c("RT"=expression(paste("Reaction ", "times (ms)")),
                             "dprime"=expression(paste(italic("d"), ' prime')))
levels(df.M1.sum_p$DVs ) <- c("RT"=expression(paste("Reaction ", "times (ms)")),
                              "dprime"=expression(paste(italic("d"), ' prime')))

p_df_M1_sum <- df.M1.plot%>%
   ggplot(., aes(x = Morality, y = value, fill = Identity)) +
   geom_point(aes(x = Conds, y = value, group = Subject),   # plot individual points
              colour = "#000000",
              size = 3, shape = 20, alpha = 0.1)+
   geom_line(aes(x = Conds, y = value, group = Subject),         # link individual's points by transparent grey lines
             linetype = 1, size = 0.8, colour = "#000000", alpha = 0.06) +   
   geom_line(data = df.M1.sum_p, aes(x = as.numeric(Mrl_num), # plot the group means  
                                     y = value, 
                                     group = Identity, 
                                     colour = Identity), 
             linetype = 1, position = pd1, size = 2)+
   geom_point(data = df.M1.sum_p, aes(x = as.numeric(Mrl_num), # group mean
                                      y = value, 
                                      group = Identity, 
                                      colour = Identity), 
              shape = 18, position = pd1, size = 8) +
   geom_errorbar(data = df.M1.sum_p, aes(x = as.numeric(Mrl_num),  # group error bar.
                                         y = value, group = Identity, 
                                         colour = Identity,
                                         ymin = value- 1.96*se, 
                                         ymax = value+ 1.96*se), 
                 width = .05, position = pd1, size = 2, alpha = 0.75) +
   scale_colour_brewer(palette = "Dark2")+
   scale_x_continuous(breaks=c(1, 2),
                      labels=c("Good", "Bad"))+
   scale_fill_brewer(palette = "Dark2")+
   ggtitle("A. Matching task") +
   theme_bw()+
   theme(panel.grid.major = element_blank(),
         panel.grid.minor = element_blank(),
         panel.background = element_blank(),
         panel.border = element_blank(),
         text=element_text(family='Times'),
         legend.title=element_blank(),
         legend.text = element_text(size =16),
         plot.title = element_text(lineheight=.8, face="bold", size = 18, margin=margin(0,0,20,0)),
         axis.text = element_text (size = 16, color = 'black'),
         axis.title = element_text (size = 16),
         axis.title.x = element_blank(),
         axis.title.y = element_blank(),
         axis.line.x = element_line(color='black', size = 1),    # increase the size of font
         axis.line.y = element_line(color='black', size = 1),    # increase the size of font
         strip.text = element_text (size = 16, color = 'black'), # size of text in strips, face = "bold"
         panel.spacing = unit(3, "lines")
   ) +
   facet_wrap( ~ DVs,
               scales = "free_y", nrow = 1,
               labeller = label_parsed)

pdf('Fig3_A_R1.pdf',  height = 6, width = 9)
p_df_M1_sum
dev.off()

### plot id-based data
df.C1_Id.plot <- df.C1.V.sum_rt_acc_l %>%
   dplyr::mutate(RT = RT*1000) %>%
   dplyr::filter(Task == 'Id') %>%  # select matching data for plotting only.
   #dplyr::full_join(., df.M1.V.SDT_l) %>%  
   tidyr::pivot_longer(., cols = c(RT, ACC), 
                       names_to = 'DVs', 
                       values_to = "value") %>% # to longer format
   dplyr::mutate(Identity = factor(Identity, levels = c('Self','Other')),
                 DVs = factor(DVs, levels = c('RT', 'ACC')),
                 # create an extra column for ploting the individual data cross different conditions.
                 Conds = mosaic::derivedFactor("0.88" = (Identity == "Self" & Morality == 'Good'), 
                                               "1.12" = (Identity == "Other" & Morality == 'Good'), 
                                               "1.88" = (Identity == "Self" & Morality == 'Bad'),
                                               "2.12" = (Identity == "Other" & Morality == 'Bad'), 
                                               method ="first", .default = NA),
                 Conds = as.numeric(as.character(Conds)))


df.C1_Id.sum_p <- summarySE(df.C1_Id.plot, measurevar = "value", groupvars = c("Identity", 'Morality',"DVs")) %>%
   dplyr::mutate(Mrl_num = ifelse(Morality == 'Good', 1, 2))

levels(df.C1_Id.plot$DVs ) <- c("RT"= expression("Reaction times (ms)"),
                             "ACC"= expression("Accuracy"))
levels(df.C1_Id.sum_p$DVs ) <- c("RT"= expression("Reaction times (ms)"),
                              "ACC"= expression("Accuracy"))

p_df_C1_Id_sum <- df.C1_Id.plot%>%
   ggplot(., aes(x = Morality, y = value, fill = Identity)) +
   geom_point(aes(x = Conds, y = value, group = Subject),   # plot individual points
              colour = "#000000",
              size = 3, shape = 20, alpha = 0.1)+
   geom_line(aes(x = Conds, y = value, group = Subject),         # link individual's points by transparent grey lines
             linetype = 1, size = 0.8, colour = "#000000", alpha = 0.06) +   
   geom_line(data = df.C1_Id.sum_p, aes(x = as.numeric(Mrl_num), # plot the group means  
                                     y = value, 
                                     group = Identity, 
                                     colour = Identity), 
             linetype = 1, position = pd1, size = 2)+
   geom_point(data = df.C1_Id.sum_p, aes(x = as.numeric(Mrl_num), # group mean
                                      y = value, 
                                      group = Identity, 
                                      colour = Identity), 
              shape = 18, position = pd1, size = 8) +
   geom_errorbar(data = df.C1_Id.sum_p, aes(x = as.numeric(Mrl_num),  # group error bar.
                                         y = value, group = Identity, 
                                         colour = Identity,
                                         ymin = value- 1.96*se, 
                                         ymax = value+ 1.96*se), 
                 width = .05, position = pd1, size = 2, alpha = 0.75) +
   scale_x_continuous(breaks=c(1, 2),
                      labels=c("Good", "Bad"))+
   scale_colour_brewer(palette = "Dark2")+
   scale_fill_brewer(palette = "Dark2")+
   ggtitle("B. Identity-based categorization task") +
   theme_bw()+
   theme(panel.grid.major = element_blank(),
         panel.grid.minor = element_blank(),
         panel.background = element_blank(),
         panel.border = element_blank(),
         text=element_text(family='Times'),
         legend.title=element_blank(),
         legend.text = element_text(size =16),
         plot.title = element_text(lineheight=.8, face="bold", size = 18, margin=margin(0,0,20,0)),
         axis.text = element_text (size = 16, color = 'black'),
         axis.title = element_text (size = 16),
         axis.title.x = element_blank(),
         axis.title.y = element_blank(),
         axis.line.x = element_line(color='black', size = 1),   # increase the size of font
         axis.line.y = element_line(color='black', size = 1),   # increase the size of font
         strip.text = element_text (size = 16, color = 'black'), # size of text in strips, face = "bold"
         panel.spacing = unit(3, "lines")
   ) +
   facet_wrap( ~ DVs,
               scales = "free_y", nrow = 1) 

pdf('Fig3_B_R1.pdf',  height = 6, width = 9)
p_df_C1_Id_sum
dev.off()

### plot val-based data
df.C1_Val.plot <- df.C1.V.sum_rt_acc_l %>%
   dplyr::mutate(RT = RT*1000) %>%
   dplyr::filter(Task == 'Val') %>%  # select matching data for plotting only.
   #dplyr::full_join(., df.M1.V.SDT_l) %>%  
   tidyr::pivot_longer(., cols = c(RT, ACC), 
                       names_to = 'DVs', 
                       values_to = "value") %>% # to longer format
   dplyr::mutate(Identity = factor(Identity, levels = c('Self','Other')),
                 DVs = factor(DVs, levels = c('RT', 'ACC')),
                 # create an extra column for ploting the individual data cross different conditions.
                 Conds = mosaic::derivedFactor("0.88" = (Identity == "Self" & Morality == 'Good'), 
                                               "1.12" = (Identity == "Other" & Morality == 'Good'), 
                                               "1.88" = (Identity == "Self" & Morality == 'Bad'),
                                               "2.12" = (Identity == "Other" & Morality == 'Bad'), 
                                               method ="first", .default = NA),
                 Conds = as.numeric(as.character(Conds)))


df.C1_Val.sum_p <- summarySE(df.C1_Val.plot, measurevar = "value", groupvars = c("Identity", 'Morality',"DVs")) %>%
   dplyr::mutate(Mrl_num = ifelse(Morality == 'Good', 1, 2))

levels(df.C1_Val.plot$DVs ) <- c("RT"= expression("Reaction times (ms)"),
                                "ACC"= expression("Accuracy"))
levels(df.C1_Val.sum_p$DVs ) <- c("RT"= expression("Reaction times (ms)"),
                                 "ACC"= expression("Accuracy"))


p_df_C1_Val_sum <- df.C1_Val.plot%>%
   ggplot(., aes(x = Morality, y = value, fill = Identity)) +
   geom_point(aes(x = Conds, y = value, group = Subject),   # plot individual points
              colour = "#000000",
              size = 3, shape = 20, alpha = 0.1)+
   geom_line(aes(x = Conds, y = value, group = Subject),         # link individual's points by transparent grey lines
             linetype = 1, size = 0.8, colour = "#000000", alpha = 0.06) +   
   geom_line(data = df.C1_Id.sum_p, aes(x = as.numeric(Mrl_num), # plot the group means  
                                        y = value, 
                                        group = Identity, 
                                        colour = Identity), 
             linetype = 1, position = pd1, size = 2)+
   geom_point(data = df.C1_Id.sum_p, aes(x = as.numeric(Mrl_num), # group mean
                                         y = value, 
                                         group = Identity, 
                                         colour = Identity), 
              shape = 18, position = pd1, size = 8) +
   geom_errorbar(data = df.C1_Id.sum_p, aes(x = as.numeric(Mrl_num),  # group error bar.
                                            y = value, group = Identity, 
                                            colour = Identity,
                                            ymin = value- 1.96*se, 
                                            ymax = value+ 1.96*se), 
                 width = .05, position = pd1, size = 2, alpha = 0.75) +
   scale_x_continuous(breaks=c(1, 2),
                      labels=c("Good", "Bad"))+
   scale_colour_brewer(palette = "Dark2")+
   scale_fill_brewer(palette = "Dark2")+
   ggtitle("C. Valence-based categorization task") +
   theme_bw()+
   theme(panel.grid.major = element_blank(),
         panel.grid.minor = element_blank(),
         panel.background = element_blank(),
         panel.border = element_blank(),
         text=element_text(family='Times'),
         legend.title=element_blank(),
         legend.text = element_text(size =16),
         plot.title = element_text(lineheight=.8, face="bold", size = 18, margin=margin(0,0,20,0)),
         axis.text = element_text (size = 16, color = 'black'),
         axis.title = element_text (size = 16),
         axis.title.x = element_blank(),
         axis.title.y = element_blank(),
         axis.line.x = element_line(color='black', size = 1),   # increase the size of font
         axis.line.y = element_line(color='black', size = 1),   # increase the size of font
         strip.text = element_text (size = 16, color = 'black'), # size of text in strips, face = "bold"
         panel.spacing = unit(3, "lines")
   ) +
   facet_wrap( ~ DVs,
               scales = "free_y", nrow = 1) 

pdf('Fig3_C_R1.pdf',  height = 6, width = 9)
p_df_C1_Val_sum
dev.off()