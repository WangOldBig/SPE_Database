E-Prime has frozen after block 3 in the female version.

I need to figure out if it is possible to recover the data from these first three blocks

