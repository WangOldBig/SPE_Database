library(lme4)
library(readr)
library(lmerTest)



# load data from your directory
d <- read_csv("MoD_full_E1.csv")
d <- read_csv("MoD_full_E2.csv")


#--------------------------------------------------------------------
d$shape_num = ifelse(d$shape == 'self', 1, ifelse(d$shape == 'friend', 0, -1))
d$type_num = ifelse(d$type == 'match', 1, -1)
d$blocktype_num = ifelse(d$blocktype == 'mixed', 1, -1)


dcor <- subset(d, correct == 1)


#full model
mdl1 <- lmer(latency ~ shape_num * type_num * blocktype_num + (1|subject), data = dcor, REML = FALSE)
summary(mdl1)

# only matching trials
dcor <- subset(d, correct == 1)
dcor <- subset(dcor, type == 'match')

mdl1 <- lmer(latency ~ shape_num * blocktype_num + (1|subject), data = dcor, REML = FALSE)
summary(mdl1)

# Shape Association for blocked
dcor <- subset(d, correct == 1)
dcor <- subset(dcor, type == 'match')
dcor <- subset(dcor, blocktype == 'blocked')

mdl1 <- lmer(latency ~ shape_num + (1|subject), data = dcor, REML = FALSE)
summary(mdl1)

# compare self vs. friend and stranger
dcor <- subset(d, correct == 1)
dcor <- subset(dcor, type == 'match')
dcor <- subset(dcor, blocktype == 'blocked')
dcor <- subset(dcor, shape != 'friend') #change to stranger

mdl1 <- lmer(latency ~ shape_num + (1|subject), data = dcor, REML = FALSE)
summary(mdl1)

# Shape Association for mixed
dcor <- subset(d, correct == 1)
dcor <- subset(dcor, type == 'match')
dcor <- subset(dcor, blocktype == 'mixed')

mdl1 <- lmer(latency ~ shape_num + (1|subject), data = dcor, REML = FALSE)
summary(mdl1)

# compare self vs. friend and stranger
dcor <- subset(d, correct == 1)
dcor <- subset(dcor, type == 'match')
dcor <- subset(dcor, blocktype == 'mixed')
dcor <- subset(dcor, shape != 'friend') #change to stranger

mdl1 <- lmer(latency ~ shape_num + (1|subject), data = dcor, REML = FALSE)
summary(mdl1)

#for nonmatch trials
dcor <- subset(d, correct == 1)
dcor <- subset(dcor, type == 'nonmatch')

mdl1 <- lmer(latency ~ shape_num * blocktype_num + (1|subject), data = dcor, REML = FALSE)
summary(mdl1)






#analysis on accuracy
mdl1 <- glmer(correct ~ shape_num * type_num * blocktype_num + (1|subject),family = binomial, data = d)
summary(mdl1)


#for match trials
dcor <- subset(d, type == 'match')
mdl1 <- glmer(correct ~ shape_num * blocktype_num + (1|subject),family = binomial, data = dcor)
summary(mdl1)

# for Shape association
dcor <- subset(d, type == 'match')
dcor <- subset(dcor, blocktype == 'mixed')
mdl1 <- glmer(correct ~ shape_num + (1|subject),family = binomial, data = dcor)
summary(mdl1)

#comparing self vs. friend and stranger
dcor <- subset(d, type == 'match')
dcor <- subset(dcor, blocktype == 'mixed')
dcor <- subset(dcor, shape != 'friend')

mdl1 <- glmer(correct ~ shape_num + (1|subject),family = binomial, data = dcor)
summary(mdl1)

#for nonmatch trials
dcor <- subset(d, type == 'nonmatch')
mdl1 <- glmer(correct ~ shape_num * blocktype_num + (1|subject),family = binomial, data = dcor)
summary(mdl1)

